# Freedom Units

Changes all temperatures into fahrenheit
