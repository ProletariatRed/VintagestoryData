# Wild Vine Grow

Small server-side Vintage Story code mod for 1.22 that lets vanilla `wildvine-*end-*` blocks grow downward.

Default behavior:

- The first growth cycle starts after 0.25 in-game hours.
- Later cycles start every 8.4 in-game hours.
- Each wild vine end has a 25% chance to grow one block down.
- A vine strand stops growing at 16 connected blocks by default.
- Loaded chunks and chunks near online players are sampled.
- Work is spread over time: only 8 chunks are scanned per second by default.
- A cycle stops after 64 successful growths by default.

On first server start the mod writes this config:

`ModConfig/WildVineGrow.json`

Important settings:

- `GrowthIntervalHours`: how often a growth cycle starts, in game hours.
- `FirstCycleDelayHours`: delay before the first cycle after server start.
- `GrowthChance`: chance for each vine end found during a cycle.
- `MaxVineLength`: maximum connected length of one hanging vine strand.
- `DebugLogging`: logs how many vine ends were found, blocked, and grown each cycle.
- `DebugSampleLimit`: logs a few concrete vine positions and the block below them.
- `ScanLoadedChunks`: scan currently loaded chunks.
- `ScanChunksNearPlayers`: also scan chunks in a radius around online players.
- `PlayerScanRadiusBlocks`: radius used for the player-centered scan.
- `ChunksPerWorkTick`: how many chunks are scanned per work tick.
- `MaxChunksPerCycle`: how many loaded chunks can be sampled per cycle.
- `MaxGrowthsPerCycle`: hard cap for new vine blocks per cycle.

Lower `ChunksPerWorkTick`, `MaxChunksPerCycle`, or `MaxGrowthsPerCycle` if a busy multiplayer server still needs gentler behavior.

Version 1.0.3 shortens the default growth interval by 30% compared with 1.0.2. If an existing config still has the old default value of `12.0`, it is migrated to `8.4` automatically.

Version 1.0.4 adds `MaxVineLength`, default `16`.

Version 1.0.5 delays first calendar access until the first server tick to avoid startup timing issues.

Version 1.0.6 is packaged with forward-slash ZIP entries for Linux/Unix servers.

Version 1.0.7 prioritizes chunks nearest to online players before sampling other loaded chunks. This makes newly placed nearby vine tips much more reliable while keeping the scan spread over time.
