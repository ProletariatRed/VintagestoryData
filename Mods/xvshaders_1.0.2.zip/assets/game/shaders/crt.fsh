#version 330 core

uniform sampler2D primaryScene;

uniform int crtCMY;
uniform int crtLightBleed;
uniform float crtBrightness;
uniform float crtCurvature;
uniform int crtPhosphorType;
uniform int crtPhosphorSize;
uniform float crtDotPitch;

in vec2 v_invFrameSize;
in vec2 texCoord;

out vec4 outColor;

vec2 CRTWarp(vec2 uv)
{
    vec2 d = uv - vec2(0.5);
    float r2 = d.x * d.x + d.y * d.y;
    return 0.5 + d * (1.0 + r2 * crtCurvature);
}

float shadowMask(vec2 frag, float size)
{
    vec2 cell = fract(frag / size);
    float mx = step(crtDotPitch, cell.x) * step(cell.x, 1.0 - crtDotPitch);
    float my = step(crtDotPitch, cell.y) * step(cell.y, 1.0 - crtDotPitch);
    float result = 0.0;
    switch (crtPhosphorType) {
        case 1:
            result = my;
            break;
        case 2:
            result = mx;
            break;
        case 3: {
            float cellX = floor(frag.x / size);
            float cellY = floor(frag.y / size);
            float columnGroup = floor(mod(cellX, 2 * 3.0)) / 3.0;
            float pattern = mod(cellY + columnGroup, 2.0);
            float slot;
            if (pattern < 1.0) {
                slot = step(cell.y, 1.0 - crtDotPitch);
            } else {
                slot = step(crtDotPitch, cell.y);
            }
            result = mx * slot;
            break;
        }
        default:
            result = mx * my;
    }
    return result;                                                                                                     
}

vec3 phosphorRouting(vec2 frag, float size)
{
    float x = floor(frag.x / size);
    float y = floor(frag.y / size);
    float idx = 0.0;
    switch (crtPhosphorType) {
        case 1:
            idx = mod(y, 3.0);
            break;
        case 2:
            idx = mod(x, 3.0);
            break;
        case 3:
            idx = mod(x, 3.0);
            break;
        case 4:
            idx = mod(x * 2 + y * 1.5, 3.0);
            break;
        default:
            idx = mod(x + y, 3.0);
    }
    
    vec3 result = vec3(0.0);
    if (crtCMY > 0) {
        if (idx < 0.99) {
            result = vec3(0.0, 1.0, 1.0);
        } else if (idx < 1.99) {
            result = vec3(1.0, 0.0, 1.0);
        } else {
            result = vec3(1.0, 1.0, 0.0);
        }
    } else {
        if (idx < 0.99) {
            result = vec3(1.0, 0.0, 0.0);
        } else if (idx < 1.99) {
            result = vec3(0.0, 1.0, 0.0);
        } else {
            result = vec3(0.0, 0.0, 1.0);
        }
    }
    return result;
}

vec3 litPhosphor(vec2 screenCoord, float size)
{
    vec2 cellIndex = floor(screenCoord / size);
    vec2 cellCenter = (cellIndex + 0.5) * size;
    vec2 cellUV = CRTWarp(cellCenter * v_invFrameSize);
    vec3 result = vec3(0.0);
    if (cellUV.x >= 0.0 && cellUV.x <= 1.0 && cellUV.y >= 0.0 && cellUV.y <= 1.0) {
        vec3 beam = texture(primaryScene, cellUV).rgb;
        vec2 cellFract = fract(screenCoord / size);
        float mask = shadowMask(screenCoord, size);
        vec3 phosphor = phosphorRouting(screenCoord, size);
        result = beam * mask * phosphor;
    }
    return result;
}

vec3 phosphorGlow(vec2 screenCoord, float size)
{
    vec3 glow = vec3(0.0);
    if (crtLightBleed > 0) {
        const int radius = 2;
        float weightSum = 0.0;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                if (x != 0 || y != 0) {
                    float dist = length(vec2(float(x), float(y)));
                    float falloff = exp(-dist);
                    vec2 neighborCoord = screenCoord + vec2(float(x), float(y));
                    vec3 emitted = litPhosphor(neighborCoord, size);
                    glow += emitted * falloff;
                    weightSum += falloff;
                }
            }
        }
        if (weightSum > 0.0) {
            glow /= weightSum;
        }
    }
    return glow;
}

float edgeFade(vec2 uv)
{
    float s = 30.0 * v_invFrameSize.x;
    float e = smoothstep(0.0, s, uv.x) *
    smoothstep(0.0, s, uv.y) *
    smoothstep(0.0, s, 1.0 - uv.x) *
    smoothstep(0.0, s, 1.0 - uv.y);
    return pow(e, 0.5);
}

void main()
{
    float size = max(1.0, float(crtPhosphorSize));
    vec2 maskCoord = gl_FragCoord.xy;
    vec2 warpedUV = CRTWarp(texCoord);
    vec4 finalColor = vec4(0.0, 0.0, 0.0, 1.0);
    if (warpedUV.x >= 0.0 && warpedUV.x <= 1.0 && warpedUV.y >= 0.0 && warpedUV.y <= 1.0) {
        vec3 lit = litPhosphor(maskCoord, size);
        vec3 glow = phosphorGlow(maskCoord, size);
        vec3 color = (lit + glow) * edgeFade(warpedUV) * crtBrightness;
        finalColor = vec4(color, 1.0);
    }
    outColor = finalColor;
}