#version 330 core


in vec2 texCoord;
in vec2 v_invFrameSize;
out vec4 outColor;

uniform sampler2D primaryScene;
uniform int edgeeffectsEdgeType;
uniform float edgeeffectsSensitivity;
uniform int edgeeffectsEdgeRadius;
uniform float edgeeffectsWaviness;
uniform float edgeeffectsWaveFrequency;

// ----------------------------
// Sobel edge detection
// ----------------------------

float luminance(vec3 c) {
    return dot(c, vec3(0.299, 0.587, 0.114));
}

float sobel(vec2 uv) {
    float radius = max(1.0, floor(edgeeffectsEdgeRadius + 0.5));
    vec2 px = v_invFrameSize * radius;

    float tl = luminance(texture(primaryScene, uv + px * vec2(-1, -1)).rgb);
    float  l = luminance(texture(primaryScene, uv + px * vec2(-1,  0)).rgb);
    float bl = luminance(texture(primaryScene, uv + px * vec2(-1,  1)).rgb);

    float  t = luminance(texture(primaryScene, uv + px * vec2( 0, -1)).rgb);
    float  b = luminance(texture(primaryScene, uv + px * vec2( 0,  1)).rgb);

    float tr = luminance(texture(primaryScene, uv + px * vec2( 1, -1)).rgb);
    float  r = luminance(texture(primaryScene, uv + px * vec2( 1,  0)).rgb);
    float br = luminance(texture(primaryScene, uv + px * vec2( 1,  1)).rgb);

    float gx = -tl - 2.0*l - bl + tr + 2.0*r + br;
    float gy = -tl - 2.0*t - tr + bl + 2.0*b + br;

    return sqrt(clamp(gx * gx + gy * gy, 0, 1)) * edgeeffectsSensitivity;
}

vec3 blur(vec2 uv, float radius)
{
    vec3 c = vec3(0.0);

    vec2 stepH = vec2(v_invFrameSize.x * radius, 0.0);
    vec2 stepV = vec2(0.0, v_invFrameSize.y * radius);

    c += texture(primaryScene, uv).rgb * 0.25;
    c += texture(primaryScene, uv + stepH).rgb * 0.125;
    c += texture(primaryScene, uv - stepH).rgb * 0.125;
    c += texture(primaryScene, uv + stepV).rgb * 0.125;
    c += texture(primaryScene, uv - stepV).rgb * 0.125;

    c += texture(primaryScene, uv + stepH + stepV).rgb * 0.0625;
    c += texture(primaryScene, uv - stepH + stepV).rgb * 0.0625;
    c += texture(primaryScene, uv + stepH - stepV).rgb * 0.0625;
    c += texture(primaryScene, uv - stepH - stepV).rgb * 0.0625;

    return c;
}

float blurMask(vec2 uv, float radius)
{
    float sum = 0.0;
    float total = 0.0;

    for (int x = -3; x <= 3; x++) {
        for (int y = -3; y <= 3; y++) {
            float w = exp(-(float(x*x + y*y)) / (2.0 * radius * radius));
            vec2 offset = vec2(x, y) * v_invFrameSize;

            float e = sobel(uv + offset);
            float m = smoothstep(0.1, 0.3, e);

            sum += m * w;
            total += w;
        }
    }

    return sum / total;
}

float hash(vec2 p) {
    vec3 p3  = fract(vec3(p.xyx) * .1031);
    p3 += dot(p3, p3.yzx + 33.33);

    return fract((p3.x + p3.y) * p3.z);
}

// ----------------------------
// Main
// ----------------------------

void main() {
    float radius = max(1.0, floor(edgeeffectsEdgeRadius + 0.5));

    vec2 displacement = vec2(
        (hash(texCoord) * sin(texCoord.y * edgeeffectsWaveFrequency)) ,
        (hash(texCoord) * cos(texCoord.x * edgeeffectsWaveFrequency))
    ) * edgeeffectsWaviness * v_invFrameSize;
    
    vec3 color = texture(primaryScene, texCoord + displacement).rgb;
    float edge = sobel(texCoord + displacement);
    float mask = smoothstep(0.1, 0.3, edge);
    
    vec3 finalColor = color;

    switch (edgeeffectsEdgeType) {
        case 0: // black border
        {
            vec3 finalColor = mix(color, vec3(0.0), mask);
            outColor = vec4(finalColor, 1.0);
            break;
        }
        case 1: // aura
        {
            float aura = blurMask(texCoord + displacement, radius);

            // remove the core so only the "glow" remains
            aura = max(0.0, aura - mask);

            vec3 auraColor = color;

            finalColor = color + auraColor * aura * 0.8;
            outColor = vec4(finalColor, 1.0);
            break;
        }
        case 2: // blur - use both a horizontal and vertical pass
        {
            vec3 blurred = blur(texCoord + displacement, radius);
            finalColor = mix(color, blurred, mask);
            outColor = vec4(finalColor, 1.0);
            break;
        }
        default:
        {
            outColor = vec4(color, 1.0);
            break;
        }
    }

}