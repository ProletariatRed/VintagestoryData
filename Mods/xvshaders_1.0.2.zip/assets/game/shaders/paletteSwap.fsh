#version 330 core

uniform sampler2D primaryScene;

in vec2 texCoord;
out vec4 outColor;

// ----------------------------
// Channel shift controls
// ----------------------------

uniform float paletteswapRedRemapping;
uniform float paletteswapGreenRemapping;
uniform float paletteswapBlueRemapping;
uniform float paletteswapRedSaturation;
uniform float paletteswapGreenSaturation;
uniform float paletteswapBlueSaturation;
uniform int paletteswapColorDepth;
uniform int paletteswapSynthwavePalette;

// ----------------------------
// Main transform
// ----------------------------

vec3 applyChannelShift(vec3 c) {
    float rr = clamp(paletteswapRedRemapping, -1.0, 1.0);
    float gr = clamp(paletteswapGreenRemapping, -1.0, 1.0);
    float br = clamp(paletteswapBlueRemapping, -1.0, 1.0);

    // Each column represents how much r/g/b contributes to output r/g/b
    vec3 outR = vec3(1.0 - abs(rr), max(0.0, -rr), max(0.0,  rr));
    vec3 outG = vec3(max(0.0,  gr), 1.0 - abs(gr), max(0.0, -gr));
    vec3 outB = vec3(max(0.0, -br), max(0.0,  br), 1.0 - abs(br));

    // Normalize so weights sum to 1
    outR /= max(dot(outR, vec3(1.0)), 0.0001);
    outG /= max(dot(outG, vec3(1.0)), 0.0001);
    outB /= max(dot(outB, vec3(1.0)), 0.0001);

    return clamp(vec3(dot(outR, c), dot(outG, c), dot(outB, c)), 0.0, 1.0);
}

vec3 applySynthwavePalette(
    vec3 color,
    float strength,
    float saturation,
    float redMagentaPush,
    float bluePurplePush,
    float highlightBoost
)
{
    vec3 c = color;

    // --- Saturation
    float luma = c.r * 0.299 + c.g * 0.587 + c.b * 0.114;

    c.r = luma + (c.r - luma) * saturation;
    c.g = luma + (c.g - luma) * saturation;
    c.b = luma + (c.b - luma) * saturation;

    // --- Red -> Magenta
    float redDominant = c.r - c.b;
    if (redDominant < 0.0) redDominant = 0.0;

    c.b += redDominant * redMagentaPush * 0.25;

    // --- Blue -> Purple (gentler)
    float blueDominant = c.b - c.r;
    if (blueDominant < 0.0) blueDominant = 0.0;

    c.r += blueDominant * bluePurplePush * 0.12;

    // --- Highlight boost
    float maxRB = c.r;
    if (c.b > maxRB) maxRB = c.b;

    if (maxRB > 0.6)
    {
        float t = (maxRB - 0.6) / 0.4;
        if (t > 1.0) t = 1.0;

        c.r += t * 0.15 * highlightBoost;
        c.b += t * 0.20 * highlightBoost;
    }

    c.r = clamp(c.r, 0.0, 1.0);
    c.g = clamp(c.g, 0.0, 1.0);
    c.b = clamp(c.b, 0.0, 1.0);

    // --- Blend with original
    return color * (1.0 - strength) + c * strength;
}

vec3 applySaturation(vec3 color, float redSat, float greenSat, float blueSat) {
    vec3 result = vec3(color);

    result.r *= redSat;
    result.g *= greenSat;
    result.b *= blueSat;

    return result;
}

vec3 applyColorDepth(vec3 color, float levels) {
    if (levels <= 1) return color;

    return floor(color * (levels - 1.0) + 0.5) / (levels - 1.0);
}

// ----------------------------
// Main
// ----------------------------

void main() {
    vec3 color = texture(primaryScene, texCoord).rgb;

    color = applyChannelShift(color);

    if (paletteswapSynthwavePalette > 0) {
        color = applySynthwavePalette(color, 0.9, 1.4, 0.8, 0.8, 0.8);
    }

    color *= vec3(paletteswapRedSaturation, paletteswapGreenSaturation, paletteswapBlueSaturation);

    color = applyColorDepth(color, pow(2, paletteswapColorDepth));

    outColor = vec4(color, 1.0);
}
