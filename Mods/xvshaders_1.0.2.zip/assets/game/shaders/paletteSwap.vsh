#version 330 core

in vec3 vertexPosition;

out vec2 texCoord;

void main()
{
    gl_Position = vec4(vertexPosition, 1.0);
    texCoord = (vertexPosition.xy + 1.0) * 0.5;
}