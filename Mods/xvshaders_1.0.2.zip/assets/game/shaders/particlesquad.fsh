#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

in vec4 color;
in vec2 uv;
in vec4 rgbaFog;
in vec3 vexPos;
in float fogAmount;
in float glowLevel;
in float extraWeight;

uniform sampler2D particleTex;
uniform float timeCounter;

#include fogandlight.fsh
#include underwatereffects.fsh
#include oit.fsh

float random(vec2 co) {
    return fract(sin(dot(co.xy ,vec2(12.9898,78.233))) * 43758.5453);
}

float valueNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f); // smoothstep curve

    float a = random(i);
    float b = random(i + vec2(1.0, 0.0));
    float c = random(i + vec2(0.0, 1.0));
    float d = random(i + vec2(1.0, 1.0));

    return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
}

void main()
{
    vec4 outColor;

    float murkiness=getUnderwaterMurkiness();
    if (murkiness > 0) {
        outColor = applyFogAndShadow(color, 0);
        outColor.rgb = applyUnderwaterEffects(outColor.rgb, murkiness);
    } else {
        outColor = applyFogAndShadow(color, fogAmount);
    }

    if (extraWeight > 1.0) { // excludes rain particles
        vec2 center = vec2(0.5, 0.5);
        vec2 offset = (uv - center) / 1.2;
        float dist_sq = length(offset);
        dist_sq = dist_sq * dist_sq;

        float n1 = valueNoise(uv * 6.5 + vec2(0.0, timeCounter * 6.1));
        float n2 = valueNoise(uv * 8.0 + vec2(0.0, timeCounter * 3.6));
        float compositeNoise = ((n1 * 0.35 + n2 * 0.65) - 0.5) * 0.35;

        // Noise influence higher at edges
        float noiseDensity = dist_sq * 6 + compositeNoise * dist_sq * 7.2;

        float softEdge = 1.0 - noiseDensity;

        // The center looks brighter & denser than the edges
        float colorModifier = (0.75 + max(0.0, 1.0 - dist_sq * 3.6) * 0.25);
        outColor.rgb *= colorModifier;
        outColor.a *= softEdge * colorModifier;
    }
    // Discard very transparent fragments; uses a higher threshold than vanilla
    if (outColor.a < 0.004) discard;

    OIT(clamp(outColor, vec4(0.0), vec4(1.0)), glowLevel);

}

