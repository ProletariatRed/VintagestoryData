uniform float timeCounter;
uniform float windWaveCounter;
uniform float windWaveCounterHighFreq;
uniform float waterWaveCounter;
uniform float windSpeed;
uniform vec3 playerpos;
uniform float globalWarpIntensity;

uniform float glitchWaviness = 0;
uniform float windWaveIntensity = 1;
uniform float waterWaveIntensity = 1;

uniform int perceptionEffectId = 1;
uniform float perceptionEffectIntensity = 1;

#ifdef VOLUMETRICSHADINGMOD
// Wind direction for directional foliage (injected by mod)
uniform vec2 windDir = vec2(1.0, 0.0);
#endif

#include noise3d.ash

#ifdef VOLUMETRICSHADINGMOD
// Gerstner wave for vertex shader
vec3 gerstnerWaveVS(vec2 pos, vec2 dir, float steepness, float wavelength, float time, float phase) {
    float k = 6.28318 / wavelength;
    float c = sqrt(9.8 / k);
    float a = steepness / k;
    float f = k * (dot(dir, pos) - c * time) + phase;
    float sinF = sin(f);
    float sharpSin = sign(sinF) * pow(abs(sinF), 0.7);
    return vec3(dir.x * a * cos(f), dir.y * a * cos(f), a * sharpSin);
}

vec3 calculateGerstnerVS(vec3 worldPos, float steepness) {
    vec2 pos = worldPos.xz;
    float time = waterWaveCounter * 0.15;
    pos += vec2(gnoise(vec3(pos * 0.02, time * 0.1)) * 3.0);
    vec2 dir1 = vec2(0.9, 0.44);
    vec2 dir2 = vec2(0.7, -0.71);
    vec2 dir3 = vec2(-0.5, 0.87);
    vec3 disp = vec3(0.0);
    disp += gerstnerWaveVS(pos, dir1, steepness, 6.0, time, 0.0);
    disp += gerstnerWaveVS(pos, dir2, steepness * 0.5, 4.2, time * 1.1, 1.7);
    disp += gerstnerWaveVS(pos, dir3, steepness * 0.25, 2.94, time * 1.2, 3.4);
    disp.z *= 2.0;
    float spatialNoise = 0.7 + 0.3 * gnoise(vec3(worldPos.xz * 0.05, time * 0.15));
    disp *= spatialNoise;
    return disp;
}
#endif

vec3 applyPerceptionWarping(vec3 worldPos) {
	if (perceptionEffectId == 2 && perceptionEffectIntensity > 0) {
		float pci = perceptionEffectIntensity * clamp(length(worldPos)/2 - 2, 0.0, 2.0);
		float xf = (worldPos.x + playerpos.x) / 10.0;
		float zf = (worldPos.z + playerpos.z) / 10.0;
		worldPos.x += pci * gnoise(vec3(xf, zf, timeCounter/6.0)) / 2.0;
		worldPos.y += pci * gnoise(vec3(xf, zf, timeCounter/10.0)) / 2.0;
		worldPos.z += pci * gnoise(vec3(xf, zf, timeCounter/3.5)) / 2.0;
	}
	return worldPos;
}

vec4 applyLiquidWarping(bool windAffected, vec4 worldPos, float div) {
	#if WAVINGSTUFF == 1
	#ifdef VOLUMETRICSHADINGMOD
	vec3 absPos = worldPos.xyz + playerpos;
	float steepness = 0.5 / max(div * 0.1, 1.0);
	vec3 disp = calculateGerstnerVS(absPos, steepness);
	worldPos.xz += disp.xy * waterWaveIntensity * 0.15;
	worldPos.y += disp.z * waterWaveIntensity * 0.15;
	#else
	vec3 noisepos = vec3((worldPos.x + playerpos.x) / 3, (worldPos.z + playerpos.z) / 3, waterWaveCounter / 8 + (windAffected ? windWaveCounter / 4 : 0));
	worldPos.y += waterWaveIntensity * gnoise(noisepos) / div;
	if (windAffected) worldPos.y += windWaveIntensity * gnoise(noisepos * 3.5) / (div * 4);
	#endif
	worldPos.xyz = applyPerceptionWarping(worldPos.xyz);
	#endif
	return worldPos;
}

vec4 applyVertexWarping(int renderFlags, vec4 worldPos) {
	#if WAVINGSTUFF == 1
	
	if ((renderFlags & WindModeBitMask) > 0) {
		
		int windMode = (renderFlags >> WindModePosition) & 0xF;
		
		if (windMode==12) {
			return applyLiquidWarping(true, worldPos, 5);
		}
		
		int windData =  (renderFlags >> WindDataPosition) & 0x7;
		
		float x = worldPos.x + playerpos.x;
		float z = worldPos.z + playerpos.z;
		
		if (windMode != 6) {
			float y = worldPos.y + playerpos.y;
			y = ceil(y * 10000) / 10000.0;
			
			float heightBend = 0;
			float strength = windWaveIntensity * (1 + windSpeed) / 30.0;
			float bendCounter = windWaveCounter;
			float vbendMul = 1/5.0;
			float wwaveHighFreq = windWaveCounterHighFreq;
			float strengthFactorY = 1;
			float bendNoiseFactor = 1.4;
			float bendConstant = 0.8;
			
			switch (windMode) {
				case 1:
				case 13:
					strength = 0.005 + 0.015 * windSpeed;
					heightBend = (fract(y) + windData) / 7.0 * 1.3;
					break;
				case 2:
					strength = 0.005 + 0.015 * windSpeed;
					heightBend = (fract(y) + windData) / 4.0 * 1.3;
					break;
				case 3:
					strength *= 0.5;
					heightBend = (fract(y) + windData) / 12.0 * 1.3;
					heightBend = heightBend / 2.0 + pow(heightBend, 1.5) / 2.0;
					break;
				case 4:
					strength = 0;
					heightBend = (fract(y) + windData) / 7.0 * 1.3;
					break;
				case 5:
					strength = 0;
					heightBend = (fract(y) + windData) / 14.0 * 1.3;
					heightBend = heightBend / 2.0 + pow(heightBend, 1.5) / 2.0;
					vbendMul = 0.0;
					break;
				case 7:
					strength = 0.01;
					heightBend = (fract(y) + windData) / 7.0 * 0.6;
					break;
				case 8:
					strength *= 0.15;
					if (windData == 0) windData = -1;
					y += (windData + 4) / 32.0;
					strengthFactorY = 3;
					break;
				case 9:
					strength *= 0.2;
					heightBend = 0;
					break;
				case 10:
					strength *= 0.5;
					heightBend = ((1 - fract(y)) + windData) / 14.0 * 1.5;
					break;
				case 11:
					strength = windData * (0.013 + 0.002 * windSpeed);
					wwaveHighFreq /= 5;
					heightBend = windData / 7.0 * 1.3;
					bendNoiseFactor = 2.4;
					bendConstant = 0.1;
					bendCounter /= 1.8;
					break;
			}
			
			float bend = windSpeed * heightBend * windWaveIntensity;
			if (bend != 0) {
				float bendNoise = windSpeed * 0.2 + bendNoiseFactor * gnoise(vec3(x * 0.1, z * 0.1, mod(bendCounter, 1024.0) * 0.25));
				bend *= (bendConstant + bendNoise);
				bend = min(4.0, bend);
			}
			
			x += wwaveHighFreq;
			y += wwaveHighFreq;
			z += wwaveHighFreq;
			
			#ifdef VOLUMETRICSHADINGMOD
			// Calculate displacement along wind direction
			float wiggleX = 2.0 * sin(x * 0.5) + sin(x + y) + sin(0.5 + 4.0*x + 2.0*y) + sin(1 + 6.0*x + 3.0*y)/3.0;
			float wiggleZ = 2.0 * sin(z * 0.25) + sin(z + 3.0 * y) + sin(0.5 + 4.0*z + 2.0*y) + sin(1 + 6.0*z + y)/3.0;
			float dispAlongWind = bend + strength * wiggleX;
			float dispPerpWind = strength * wiggleZ * 0.3;
			worldPos.x += dispAlongWind * windDir.x - dispPerpWind * windDir.y;
			worldPos.z += dispAlongWind * windDir.y + dispPerpWind * windDir.x;
			#else
			worldPos.x += bend + strength * (2 * sin(x * 0.5) + sin(x + y) + sin(0.5 + 4*x + 2*y) + sin(1 + 6*x + 3*y)/3);
			worldPos.z += strength * (2 * sin(z * 0.25) + sin(z + 3 * y) + sin(0.5 + 4*z + 2*y) + sin(1 + 6*z + y)/3);
			#endif
			
			if (windMode == 1) {
				#ifdef VOLUMETRICSHADINGMOD
				float extraWiggle = sin(x*20.0)*strength * 0.2 * windSpeed;
				worldPos.x += extraWiggle * windDir.x;
				worldPos.z += extraWiggle * windDir.y;
				#else
				worldPos.x += sin(x*20)*strength * 0.2 * windSpeed;
				#endif
			}
			worldPos.y += -bend * vbendMul + strength * strengthFactorY * (sin(5*y)/15 + cos(10*x/strengthFactorY) / 10 + sin(3*z/strengthFactorY)/2 + cos(x/strengthFactorY*2)/2.2);
		} else {
			#ifdef VOLUMETRICSHADINGMOD
			vec3 absPos = vec3(x, worldPos.y + playerpos.y, z);
			vec3 disp = calculateGerstnerVS(absPos, 0.5);
			worldPos.xz += disp.xy * 0.15;
			worldPos.y += disp.z * 0.15;
			#else
			vec3 noisepos = vec3(x / 3, z / 3, waterWaveCounter / 8 + windWaveCounter / 4);
			worldPos.y += gnoise(noisepos) / 10;
			#endif
		}
	}

	#endif
	
	return worldPos;
}

vec4 applyGlobalWarping(vec4 worldPos) {
	#if WAVINGSTUFF == 1
	
	if (glitchWaviness > 0.1) {
		float str = max(0.0, glitchWaviness - 0.1);
		str *= clamp(1.5 * length(worldPos) * glitchWaviness - 1, 0.0, 250.0);
		float xf = (worldPos.x + playerpos.x) / 10;
		float zf = (worldPos.z + playerpos.z) / 10;
		worldPos.x += str * gnoise(vec3(xf, zf, windWaveCounter/6)) / 5;
		worldPos.y += str * gnoise(vec3(xf, zf, windWaveCounter/10)) / 5;
		worldPos.z += str * gnoise(vec3(xf, zf, windWaveCounter/3.5)) / 5;
	}
	
	if (globalWarpIntensity > 0) {
		float x = max(0.0, (mod(20*windWaveCounter, 30)) + (worldPos.x + playerpos.x) * 0.2 + (worldPos.y + playerpos.y) * 0.125 - 40);
		worldPos.x += (sin(x / 2) + sin(0.5 + 2*x) + sin(1 + 3*x)/3) / 30.0 * globalWarpIntensity;
		worldPos.z += (cos(x / 3) + cos(0.2 + 2.2*x) + cos(1 + 4*x)/3) / 30.0 * globalWarpIntensity;
	}
	
	worldPos.xyz = applyPerceptionWarping(worldPos.xyz);
	#endif
	
	return worldPos;
}
