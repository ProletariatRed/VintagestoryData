uniform float waterWaveCounter;
uniform float waterFlowCounter;
uniform float windSpeed;

#ifndef VSMOD_SSR_WAVE_INTENSITY
#define VSMOD_SSR_WAVE_INTENSITY 1.0
#endif

#ifndef VSMOD_SSR_WAVE_SIZE
#define VSMOD_SSR_WAVE_SIZE 70.0
#endif

// windWaveCounter is declared in fogandlight.fsh

vec3 vsmodGerstnerWave(vec2 pos, vec2 dir, float steepness, float wavelength, float time, float phase)
{
    float k = 6.28318 / wavelength;
    float c = sqrt(9.8 / max(k, 1e-4));
    float a = steepness / max(k, 1e-4);
    float f = k * (dot(dir, pos) - c * time) + phase;
    float sinF = sin(f);
    float sharpSin = sign(sinF) * pow(abs(sinF), 0.7);
    return vec3(dir.x * a * cos(f), dir.y * a * cos(f), a * sharpSin);
}

float sharpenWave(float value) {
    float boost = 1.0 + 0.2 * abs(value);
    return clamp(value * boost, -1.0, 1.0);
}

float generateWaveNoise(vec3 coord1, float div, float sizeScale) {
    float waveTime = waterWaveCounter * 0.15;
    float scaledSize = max(0.2, sizeScale);

    // Keep SSR normals phase-aligned with mesh warping (vertexwarp.vsh).
    vec2 gerstnerPos = coord1.xz / scaledSize;
    gerstnerPos += vec2(gnoise(vec3(gerstnerPos * 0.02, waveTime * 0.1)) * 3.0);
    float steepness = 0.5 / max(div * 0.1, 1.0);
    vec3 gerstnerDisp = vec3(0.0);
    gerstnerDisp += vsmodGerstnerWave(gerstnerPos, vec2(0.9, 0.44), steepness, 6.0, waveTime, 0.0);
    gerstnerDisp += vsmodGerstnerWave(gerstnerPos, vec2(0.7, -0.71), steepness * 0.5, 4.2, waveTime * 1.1, 1.7);
    gerstnerDisp += vsmodGerstnerWave(gerstnerPos, vec2(-0.5, 0.87), steepness * 0.25, 2.94, waveTime * 1.2, 3.4);
    gerstnerDisp.z *= 2.0;
    float spatialNoise = 0.7 + 0.3 * gnoise(vec3((coord1.xz / scaledSize) * 0.05, waveTime * 0.15));
    float gerstnerHeight = gerstnerDisp.z * spatialNoise * 0.15 / max(div * 0.2, 1.0);

    vec3 scaledCoord = coord1 / scaledSize;
    vec3 coord2 = scaledCoord * 4.0 + 16.0;
    vec3 noisepos1 = vec3(scaledCoord.x - waveTime / 3.0, scaledCoord.z, waveTime / 4.0);
    vec3 noisepos2 = vec3(coord2.x - waveTime / 4.0, coord2.z, waveTime / 4.0);
    float intensity = max(0.0, VSMOD_SSR_WAVE_INTENSITY);
    float noise1 = sharpenWave(gnoise(noisepos1));
    float noise2 = sharpenWave(gnoise(noisepos2));
    float microWaves = (noise1 * 1.5 + noise2 * 0.5) / div;
    return clamp(gerstnerHeight + microWaves, -1.0, 1.0) * intensity;
}

float cellNoise(vec3 k)
{
    mat3 m = mat3(-2,-1,2, 3,-2,1, 1,2,2);
    k.xyz = k.xyz * m * 0.5;
    float d1 = length(0.5 - fract(k.xyz));
    k.xyz = k.xyz * m * 0.4;
    float d2 = length(0.5 - fract(k.xyz));
    k.xyz = k.xyz * m * 0.3;
    float d3 = length(0.5 - fract(k.xyz));
    return pow(min(min(d1, d2), d3), 6.0) * 10.0;
}

float generateCausticsNoise(vec3 coord, vec3 sunPos) {
    vec3 coord1 = coord;
    coord1.xz -= (sunPos * coord.y).xz;
    float waveTime = waterWaveCounter;
    coord1.x -= waveTime / 3.0;
    coord1 *= 0.25;

    float div = 90.0;

    vec3 noisepos1 = vec3(coord1.x, coord1.z,
        waterWaveCounter / 12.0 + waveTime / 12.0 + coord1.y);

    // Constant amplitude - no wind influence
    return (cellNoise(noisepos1) - 0.1) / div * 3.0;
}
