#ifndef VOLUMETRIC_FLATNESS
#define VOLUMETRIC_FLATNESS 1.5
#endif

#ifndef VSMOD_VOLUMETRIC_MODE
#define VSMOD_VOLUMETRIC_MODE 0
#endif

#ifndef VSMOD_VOLUMETRIC_QUALITY
#define VSMOD_VOLUMETRIC_QUALITY 1
#endif

#ifndef VSMOD_VOLUMETRIC_SAMPLES
#define VSMOD_VOLUMETRIC_SAMPLES 12
#endif

#ifndef VOLUMETRIC_INTENSITY
#define VOLUMETRIC_INTENSITY 1.0
#endif

#ifndef VSMOD_FARSHADOWOFFSET
#define VSMOD_FARSHADOWOFFSET 0.0
#endif
#ifndef VSMOD_NEARSHADOWOFFSET
#define VSMOD_NEARSHADOWOFFSET 0.0
#endif
#ifndef VSMOD_SOFTSHADOWS
#define VSMOD_SOFTSHADOWS 0
#endif

#ifndef VSMOD_HAS_SHADOW_RANGES
uniform float shadowRangeFar;
uniform float shadowRangeNear;
#endif

#ifndef VSMOD_HAS_OVEREXPOSURE_APPLY
void applyOverexposure(inout vec4 rgbaPixel, float b, vec3 normal, vec3 worldPos, float fogDensity, inout float glow) {
}
#endif

#if SHADOWQUALITY > 0
uniform mat4 toShadowMapSpaceMatrixFar;
#endif

#if VSMOD_HAS_COMPUTE
uniform sampler2D volumetricResult;
#ifndef VSMOD_FRAMESIZE_DECLARED
#define VSMOD_FRAMESIZE_DECLARED
uniform vec2 frameSize;
#endif
#endif

#if SHADOWQUALITY > 1
uniform mat4 toShadowMapSpaceMatrixNear;
#endif

void calcShadowMapCoords(vec4 worldPos, out vec4 shadowCoordsNear, out vec4 shadowCoordsFar) {
    float nearSub = 0;
    #if SHADOWQUALITY > 0
    float len = length(worldPos);
    #endif

    #if SHADOWQUALITY > 1
    // Near map
    shadowCoordsNear = toShadowMapSpaceMatrixNear * worldPos;

    float distanceNear = clamp(
    max(max(0.0, 0.03 - shadowCoordsNear.x) * 100.0, max(0.0, shadowCoordsNear.x - 0.97) * 100.0) +
    max(max(0.0, 0.03 - shadowCoordsNear.y) * 100.0, max(0.0, shadowCoordsNear.y - 0.97) * 100.0) +
    max(0.0, shadowCoordsNear.z - 0.98) * 100.0 +
    max(0.0, len / shadowRangeNear - 0.15)
    , 0.0, 1.0);

    nearSub = shadowCoordsNear.w = clamp(1.0 - distanceNear, 0.0, 1.0);

    #endif
    #if SHADOWQUALITY > 0
    // Far map
    shadowCoordsFar = toShadowMapSpaceMatrixFar * worldPos;

    float distanceFar = clamp(
    max(max(0.0, 0.03 - shadowCoordsFar.x) * 10.0, max(0.0, shadowCoordsFar.x - 0.97) * 10.0) +
    max(max(0.0, 0.03 - shadowCoordsFar.y) * 10.0, max(0.0, shadowCoordsFar.y - 0.97) * 10.0) +
    max(0.0, shadowCoordsFar.z - 0.98) * 10.0 +
    max(0.0, len / shadowRangeFar - 0.15)
    , 0.0, 1.0);

    distanceFar = distanceFar * 2.0 - 0.5;

    shadowCoordsFar.w = max(0.0, clamp(1.0 - distanceFar, 0.0, 1.0) - nearSub);

    //shadowCoordsFar.w = max(0.0, 1.0 - nearSub);

    #endif
}

float getPCFBrightness(vec4 shadowCoordsNear, vec4 shadowCoordsFar) {
    #if SHADOWQUALITY > 0

    float totalFar = 0.0;
    if (shadowCoordsFar.z < 0.999 && shadowCoordsFar.w > 0.0) {
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                float inlight = texture (shadowMapFar, vec3(shadowCoordsFar.xy + vec2(float(x) * shadowMapWidthInv, float(y) * shadowMapHeightInv), shadowCoordsFar.z - 0.0009 + (0.0001 * VSMOD_FARSHADOWOFFSET)));
                totalFar += 1.0 - inlight;
            }
        }
    }

    totalFar /= 9.0;


    float b = 1.0 - totalFar * shadowCoordsFar.w * 0.5;
    #endif


    #if SHADOWQUALITY > 1
    float totalNear = 0.0;
    if (shadowCoordsNear.z < 0.999 && shadowCoordsNear.w > 0.0) {
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                float inlight = texture (shadowMapNear, vec3(shadowCoordsNear.xy + vec2(float(x) * shadowMapWidthInv, float(y) * shadowMapHeightInv), shadowCoordsNear.z - 0.0005 + (0.0001 * VSMOD_NEARSHADOWOFFSET)));
                totalNear += 1.0 - inlight;
            }
        }
    }

    totalNear /= 9.0;


    b -= totalNear * shadowCoordsNear.w * 0.5;
    #endif

    #if SHADOWQUALITY > 0
    b = clamp(b, 0.0, 1.0);
    return b;
    #endif

    return 1.0;
}

float getPCSSBrightness(vec4 shadowCoordsNear, vec4 shadowCoordsFar, float blockBrightness, vec3 normal) {
    #if SHADOWQUALITY > 0

    #if VSMOD_SOFTSHADOWS > 0
    const vec2 vsmodFarKernel[8] = vec2[](
        vec2(0.0, 0.0),
        vec2(0.527837, 0.085683),
        vec2(-0.040088, 0.536087),
        vec2(-0.670445, -0.179949),
        vec2(0.216581, -0.682587),
        vec2(0.734351, 0.523524),
        vec2(-0.583569, 0.748541),
        vec2(-0.791559, -0.597705)
    );

    float totalFar = 0.0;
    if (shadowCoordsFar.z < 0.999 && shadowCoordsFar.w > 0.0) {
        int sampleCount = clamp(VSMOD_SOFTSHADOWSAMPLES / 3, 4, 8);
        float depthFactor = clamp(shadowCoordsFar.z, 0.0, 1.0);
        float texel = max(shadowMapWidthInv, shadowMapHeightInv);
        float radius = texel * mix(4.0, 12.0, depthFactor);
        for (int i = 0; i < 8; i++) {
            if (i >= sampleCount) break;
            vec2 offset = vsmodFarKernel[i] * radius;
            float inlight = texture (shadowMapFar, vec3(
                shadowCoordsFar.xy + offset,
                shadowCoordsFar.z - 0.0009 + (0.0001 * VSMOD_FARSHADOWOFFSET)
            ));
            totalFar += 1.0 - inlight;
        }
        totalFar /= float(sampleCount);
    }
    #else
    float totalFar = 0.0;
    if (shadowCoordsFar.z < 0.999 && shadowCoordsFar.w > 0.0) {
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                float inlight = texture (shadowMapFar, vec3(shadowCoordsFar.xy + vec2(float(x) * shadowMapWidthInv, float(y) * shadowMapHeightInv), shadowCoordsFar.z - 0.0009 + (0.0001 * VSMOD_FARSHADOWOFFSET)));
                totalFar += 1.0 - inlight;
            }
        }
    }

    totalFar /= 9.0;
    #endif


    float b = 1.0 - shadowIntensity * totalFar * shadowCoordsFar.w * 0.5;
    #endif


    #if SHADOWQUALITY > 1
    #if VSMOD_SOFTSHADOWS > 0
    float totalNear = 1.0;
    if (shadowCoordsNear.z < 0.999 && shadowCoordsNear.w > 0.0) {
        totalNear = 1.0 - vsmod_pcss_sloped(shadowCoordsNear.xyz, normal);
    }
    #else
    float totalNear = 0.0;
    if (shadowCoordsNear.z < 0.999 && shadowCoordsNear.w > 0.0) {
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                float inlight = texture (shadowMapNear, vec3(shadowCoordsNear.xy + vec2(float(x) * shadowMapWidthInv, float(y) * shadowMapHeightInv), shadowCoordsNear.z - 0.0005 + (0.0001 * VSMOD_NEARSHADOWOFFSET)));
                totalNear += 1.0 - inlight;
            }
        }
    }

    totalNear /= 9.0;
    #endif


    b -= shadowIntensity * totalNear * shadowCoordsNear.w * 0.5;
    #endif

    #if SHADOWQUALITY > 0
    b = clamp(max(b, blockBrightness * 1.2), 0.0, 1.0);
    return b;
    #endif

    return 1.0;
}

float getPCFBrightnessAt(vec4 worldPos) {
    vec4 shadowCoordNear = vec4(0.0);
    vec4 shadowCoordFar = vec4(0.0);

    calcShadowMapCoords(worldPos, shadowCoordNear, shadowCoordFar);
    return getPCFBrightness(shadowCoordNear, shadowCoordFar);
}

float getPCSSBrightnessAt(vec4 worldPos, float blockBrightness, vec3 normal) {
    vec4 shadowCoordNear = vec4(0.0);
    vec4 shadowCoordFar = vec4(0.0);

    calcShadowMapCoords(worldPos, shadowCoordNear, shadowCoordFar);
    return getPCSSBrightness(shadowCoordNear, shadowCoordFar, blockBrightness, normal);
}

vec4 applyOverexposedFogAndShadowDeferred(vec4 worldPos, vec4 rgbaPixel, float fogWeight, vec3 normal,
float normalShadeIntensity, float minNormalShade, float fogDensity, float blockBrightness, vec3 cameraPos, inout float glow) {

    float b = getPCSSBrightnessAt(worldPos, blockBrightness, normal);
    float nb = getBrightnessFromNormal(normal, normalShadeIntensity, minNormalShade);

    float outB = min(b, nb);
    #if SHADOWQUALITY > 0
    if (shadowRangeFar > 0.001) {
        float cameraDist = length(worldPos.xyz - cameraPos);
        float farFadeStart = max(24.0, shadowRangeFar * 0.60);
        float farFadeEnd = max(farFadeStart + 1.0, shadowRangeFar * 0.95);
        float farShadowFade = smoothstep(farFadeStart, farFadeEnd, cameraDist);
        outB = mix(outB, nb, farShadowFade);
    }
    #endif
    rgbaPixel *= vec4(outB, outB, outB, 1);

    applyOverexposure(rgbaPixel, b, normal, worldPos.xyz, fogDensity, glow);

    return applyFog(rgbaPixel, fogWeight);
}

float getFogLevelDeferred(float depth, float fogMin, float fogDensity, float worldPosY) {
    float clampedDepth = min(250.0, depth);
    
    float heightDiff = worldPosY - flatFogStart;
    
    float extraDistanceFog = max(-flatFogDensity * clampedDepth * flatFogStart / 60.0, 0.0);
    float distanceFog = 1.0 - 1.0 / exp(clampedDepth * (fogDensity + extraDistanceFog));
    float flatFog = 1.0 - 1.0 / exp(heightDiff * flatFogDensity);
    
    float val = max(flatFog, distanceFog);
    float nearnessToPlayer = clamp((8.0 - depth) / 8.0, 0.0, 0.9);
    val = max(min(0.04, val), val - nearnessToPlayer);
    
    val += fogMin;
    
    return clamp(val, 0.0, 1.0);
}

uint volumetricHash(uint x, uint y)
{
    x += x >> 11;
    x ^= x << 7;
    x += y;
    x ^= x << 6;
    x += x >> 15;
    x ^= x << 5;
    x += x >> 12;
    x ^= x << 9;
    return x;
}

#if VSMOD_HAS_SHADER_BIT_ENCODING
float volumetricRandom(uvec2 v) {
    const uint mantissaMask = 0x007FFFFFu;
    const uint one          = 0x3F800000u;

    uvec2 uv = floatBitsToUint(v);
    uint h = volumetricHash(uv.x, uv.y);
    h &= mantissaMask;
    h |= one;

    float  r2 = uintBitsToFloat(h);
    return r2 - 1.0;
}
#else
float volumetricRandom(uvec2 v) {
    return fract(sin(dot(vec2(v), vec2(12.9898, 78.233))) * 43758.5453);
}
#endif

// Interleaved Gradient Noise - better distribution than hash
float volumetricIGN(vec2 pos) {
    vec3 magic = vec3(0.06711056, 0.00583715, 52.9829189);
    return fract(magic.z * fract(dot(pos, magic.xy)));
}

// Temporal dithering for RayMarch mode
float volumetricTemporalDither(vec2 pos, float time) {
    float spatial = volumetricIGN(pos);
    return spatial;
}

// Henyey-Greenstein phase function for realistic scattering
float volumetricHG(float cosTheta, float g) {
    float g2 = g * g;
    float denom = 1.0 + g2 - 2.0 * g * cosTheta;
    return (1.0 - g2) / (4.0 * 3.14159265 * pow(denom, 1.5));
}

float volumetricShadowSample(vec3 coords) {
    #if SHADOWQUALITY > 0
    vec2 texel = vec2(shadowMapWidthInv, shadowMapHeightInv);
    float sum = 0.0;
    sum += texture(shadowMapFar, vec3(coords.xy, coords.z - 0.0009));
    sum += texture(shadowMapFar, vec3(coords.xy + vec2(texel.x, 0.0), coords.z - 0.0009));
    sum += texture(shadowMapFar, vec3(coords.xy + vec2(-texel.x, 0.0), coords.z - 0.0009));
    sum += texture(shadowMapFar, vec3(coords.xy + vec2(0.0, texel.y), coords.z - 0.0009));
    sum += texture(shadowMapFar, vec3(coords.xy + vec2(0.0, -texel.y), coords.z - 0.0009));
    return sum * 0.2;
    #else
    return 1.0;
    #endif
}

// Get sample count based on quality setting
int getVolumetricSamples() {
    int samples = clamp(VSMOD_VOLUMETRIC_SAMPLES, 4, 64);
    #if VSMOD_VOLUMETRIC_QUALITY == 0
    return min(samples, 8);
    #elif VSMOD_VOLUMETRIC_QUALITY == 1
    return min(samples, 16);
    #elif VSMOD_VOLUMETRIC_QUALITY == 2
    return min(samples, 24);
    #else
    return samples;
    #endif
}

float calculateVolumetricScatterDeferred(vec4 worldPos, vec4 cameraPos, float time) {
    #if VSMOD_HAS_COMPUTE && GODRAYS > 0 && VSMOD_VOLUMETRIC_MODE > 0
    // GL 4.3: read precomputed scatter from compute half-res pass
    return texture(volumetricResult, gl_FragCoord.xy / frameSize).r;
    #elif GODRAYS > 0 && VSMOD_VOLUMETRIC_MODE > 0
    float intensityMul = clamp(VOLUMETRIC_INTENSITY, 0.0, 2.5);
    if (intensityMul <= 0.001) return 0.0;

    float dist = length(worldPos.xyz - cameraPos.xyz);
    float fogStart = float(VSMOD_AERIAL_FOG_START);
    if (dist < fogStart) return 0.0;

    float density = max(0.0, max(flatFogDensity, fogDensityIn));

    #if SHADOWQUALITY > 0
    vec4 shadowCoordsFar = toShadowMapSpaceMatrixFar * worldPos;
    vec4 shadowRayStart = toShadowMapSpaceMatrixFar * cameraPos;
    vec4 shadowLightPos = toShadowMapSpaceMatrixFar * vec4(lightPosition, 0.0);

    // Temporal dithering with IGN
    float dither = volumetricTemporalDither(gl_FragCoord.xy, time);

    int maxSamples = getVolumetricSamples();

    // Adaptive: reduce samples for distant fragments
    float adaptiveMul = mix(1.0, 0.5, smoothstep(50.0, 200.0, dist));
    maxSamples = max(4, int(float(maxSamples) * adaptiveMul));

    vec3 ray = shadowCoordsFar.xyz - shadowRayStart.xyz;
    float extinction = 0.0025 + density * 0.12;
    float maxRay = min(dist - fogStart, max(30.0, 6.0 / max(extinction, 0.0001)));
    float rayFactor = maxRay / max(dist, 0.001);

    vec3 dV = ray * rayFactor / float(maxSamples);
    vec3 startOffset = ray * (fogStart / max(dist, 0.001));
    vec3 progress = shadowRayStart.xyz + startOffset + dV * dither;

    float stepLength = maxRay / float(maxSamples);
    float sigmaT = extinction;
    float sigmaS = sigmaT * 0.9;

    float transmittance = 1.0;
    float scatterAccum = 0.0;
    for (int i = 0; i < maxSamples; ++i) {
        float visibility = volumetricShadowSample(progress);
        scatterAccum += visibility * transmittance * sigmaS * stepLength;
        transmittance *= exp(-sigmaT * stepLength);
        progress += dV;
    }

    // Henyey-Greenstein phase function
    float cosTheta = dot(normalize(ray), normalize(shadowLightPos.xyz));
    float phase = volumetricHG(cosTheta, 0.78) * (4.0 * 3.14159265);

    float scatter = scatterAccum * phase;
    float safeFlatness = max(0.2, VOLUMETRIC_FLATNESS);
    scatter = pow(clamp(scatter, 0.0, 1.0), safeFlatness);
    return min(0.95, scatter * intensityMul);
    #else
    // No shadow map available: keep a subtle atmospheric contribution instead of hard-off.
    float fogEnd = float(VSMOD_AERIAL_FOG_END);
    float fallbackRange = fogEnd > 0.5 ? max(32.0, fogEnd - fogStart) : max(96.0, fogStart * 2.0);
    float depthT = clamp((dist - fogStart) / fallbackRange, 0.0, 1.0);
    float sunFacing = clamp(lightPosition.y * 0.5 + 0.5, 0.2, 1.0);
    float fogWeight = clamp(0.15 + density * 8.0, 0.15, 1.0);
    float dither = mix(0.94, 1.06, volumetricTemporalDither(gl_FragCoord.xy, time));
    float scatter = pow(depthT, 0.65) * sunFacing * fogWeight * dither;
    return clamp(scatter * 0.22 * intensityMul, 0.0, 0.35);
    #endif
    #endif
    return 0.0;
}

// Legacy function for backward compatibility
float calculateVolumetricScatterDeferred(vec4 worldPos, vec4 cameraPos) {
    return calculateVolumetricScatterDeferred(worldPos, cameraPos, 0.0);
}
