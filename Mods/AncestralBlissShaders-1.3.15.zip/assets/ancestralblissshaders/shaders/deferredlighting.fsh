
#version 330 core

uniform sampler2D gDepth;
uniform sampler2D gNormal;
uniform int vsmodNormalPacked8;
uniform sampler2D inColor;
uniform sampler2D inGlow;

uniform mat4 invProjectionMatrix;
uniform mat4 invModelViewMatrix;

uniform float dayLight;
uniform vec3 sunPosition;

in vec2 texcoord;
out vec4 outColor;
out vec4 outGlow;

uniform float fogDensityIn;
uniform float fogMinIn;
uniform vec4 rgbaFog;
uniform float volumetricTime;

#include fogandlight.fsh
#include deferredfogandlight.fsh

void main(void)
{
    float projectedZ = texture(gDepth, texcoord).r;
    vec4 color = texture(inColor, texcoord);
    vec4 glowVec = texture(inGlow, texcoord);
    
    // Sky pixels (depth >= 1.0) - preserve existing primary FBO sky.
    if (projectedZ >= 1.0) {
        discard;
    }
    
    vec4 normal = texture(gNormal, texcoord);
    float vsmodIsFarseer = 1.0 - step(-0.5, normal.w);
    if (vsmodIsFarseer > 0.5) {
        // Explicit farseer marker from region.fsh: skip deferred lighting and keep
        // region color/glow untouched.
        outColor = color;
        outGlow = glowVec;
        return;
    }
    
    float normalLenPacked = length(normal.xyz);
    if (normalLenPacked < 0.01) {
        // Region/farseer pass writes color but may leave g-normal empty.
        // Preserve that color instead of discarding the fragment.
        outColor = color;
        outGlow = glowVec;
        return;
    }
    
    if (vsmodNormalPacked8 > 0) {
        normal.xyz = normal.xyz * 2.0 - 1.0;
    }
    
    // Normalize after unpacking
    normal.xyz = normalize(normal.xyz);

    #if SHADOWQUALITY > 0
    float intensity = 0.34 + (1 - shadowIntensity)/8.0;
    #else
    float intensity = 0.45;
    #endif

    vec4 screenPosition = vec4(vec3(texcoord, projectedZ) * 2.0 - 1.0, 1.0);
    screenPosition = invProjectionMatrix * screenPosition;
    screenPosition.xyz /= screenPosition.w;
    screenPosition.w = 1.0;
    vec4 worldPosition = invModelViewMatrix * screenPosition;
    vec4 cameraWorldPos = invModelViewMatrix * vec4(0.0, 0.0, 0.0, 1.0);
    vec4 worldNormal = invModelViewMatrix * vec4(normal.xyz, 0.0);

    float fog = getFogLevelDeferred(projectedZ, fogMinIn, fogDensityIn, worldPosition.y);
    color = applyOverexposedFogAndShadowDeferred(worldPosition, color, fog, worldNormal.xyz,
    1.0, intensity, fogDensityIn, glowVec.b, cameraWorldPos.xyz, glowVec.r);

    float scatter = calculateVolumetricScatterDeferred(worldPosition, cameraWorldPos, volumetricTime);
    float brightness = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    float brightSuppression = smoothstep(0.80, 1.02, brightness);
    scatter *= mix(1.0, 0.72, brightSuppression);

    glowVec.g = max(glowVec.g, scatter);

    glowVec.z = 0.0;
    outColor = color;
    outGlow = glowVec;
}
