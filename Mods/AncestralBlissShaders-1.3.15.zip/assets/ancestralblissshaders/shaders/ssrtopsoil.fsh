#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

uniform sampler2D terrainTex;
uniform float rainStrength = 1.0;
uniform float playerUnderwater;
uniform int vsmodMrtMode;
uniform float wetOverride;
#define VSMOD_NORMAL_PACK_8BIT (VSMOD_HAS_SHADER_BIT_ENCODING == 0)

in vec3 worldPosition;
in vec4 fragPosition;
in vec3 normal;
in vec4 gnormal;
in vec2 uv;

flat in int renderFlags;


layout(location = 0) out vec4 outGPosition;
layout(location = 1) out vec4 outGNormal;
layout(location = 2) out vec4 outTint;
#if VSMOD_REFRACT > 0
layout(location = 3) out vec4 outRefraction;
#endif

#if VSMOD_REFRACT > 0
void writeGBuffer(vec4 position, vec4 normal, vec4 tint, vec4 refraction) {
    if (vsmodMrtMode == 2) {
        outGPosition = tint;
        outGNormal = refraction;
        outTint = vec4(0.0);
        outRefraction = vec4(0.0);
    } else if (vsmodMrtMode == 1) {
        outGPosition = position;
        outGNormal = normal;
        outTint = vec4(0.0);
        outRefraction = vec4(0.0);
    } else {
        outGPosition = position;
        outGNormal = normal;
        outTint = tint;
        outRefraction = refraction;
    }
}
#else
void writeGBuffer(vec4 position, vec4 normal, vec4 tint, vec4 refraction) {
    if (vsmodMrtMode == 2) {
        outGPosition = tint;
        outGNormal = refraction;
        outTint = vec4(0.0);
    } else if (vsmodMrtMode == 1) {
        outGPosition = position;
        outGNormal = normal;
        outTint = vec4(0.0);
    } else {
        outGPosition = position;
        outGNormal = normal;
        outTint = tint;
    }
}
#endif

#include noise3d.ash

void main()
{
    vec4 color = texture(terrainTex, uv);
    if (color.a < 0.02) discard;

    // Compute wetness mask independently of reflective flags.
    float wetness = clamp(max(rainStrength, wetOverride), 0.0, 1.0);
    float alpha = mix(0.9, 0.02, wetness);

    vec3 nudgedNormal = gnormal.xyz;
    nudgedNormal = normalize(nudgedNormal);
    #if VSMOD_NORMAL_PACK_8BIT
        nudgedNormal = nudgedNormal * 0.5 + 0.5;
    #endif
    vec4 refraction = vec4(0.0, 0.0, 0.0, 1.0);
    outGPosition = vec4(fragPosition.xyz, alpha);
    outGNormal = vec4(normalize(nudgedNormal), playerUnderwater);
    // Mark wet pixels with full tint to maximize SSR contribution.
    outTint = vec4(vec3(1.0), wetness);
    writeGBuffer(outGPosition, outGNormal, outTint, refraction);
}
