
#version 330 core

uniform sampler2D primaryScene;

uniform sampler2D gPosition;
uniform sampler2D gNormal;
uniform sampler2D gTint;
uniform sampler2D gDepth;
uniform sampler2D ssrHistory;

uniform int vsmodNormalPacked8;
uniform mat4 projectionMatrix;
uniform mat4 invProjectionMatrix;
uniform mat4 invModelViewMatrix;
uniform mat4 prevViewProj;
uniform int hasHistory;
uniform float historyBlend;

uniform vec3 sunPosition;
uniform float dayLight;
uniform float horizonFog;
uniform float fogDensityIn;
uniform float fogMinIn;
uniform vec4 rgbaFog;
uniform float windSpeed;

in vec2 texcoord;
out vec4 outColor;

#include dither.fsh
#include fogandlight.fsh
#include skycolor.fsh
#include deferredfogandlight.fsh

#ifndef VSMOD_SSR_REFLECTION_DIMMING
#define VSMOD_SSR_REFLECTION_DIMMING 1.0
#endif

#ifndef VSMOD_SSR_SKY_MIXIN
#define VSMOD_SSR_SKY_MIXIN 0.6
#endif

#ifndef VSMOD_SSR_TINT_INFLUENCE
#define VSMOD_SSR_TINT_INFLUENCE 0.75
#endif

#ifndef VSMOD_SSR_SPECULAR
#define VSMOD_SSR_SPECULAR 1.0
#endif

const int maxf = 7;//number of refinements
const float ref = 0.11;//refinement multiplier
const float inc = 3.0;//increasement factor at each step

vec3 nvec3(vec4 pos) {
    return pos.xyz/pos.w;
}
vec4 nvec4(vec3 pos) {
    return vec4(pos.xyz, 1.0);
}
float cdist(vec2 coord) {
    return max(abs(coord.s-0.5), abs(coord.t-0.5))*2.0;
}

vec3 decodeGNormal(vec3 packedNormal)
{
    if (vsmodNormalPacked8 > 0) {
        return normalize(packedNormal * 2.0 - 1.0);
    }
    return normalize(packedNormal);
}

#if VSMOD_HAS_COMPUTE
uniform sampler2D hizBuffer;
uniform int hizMipLevels;
uniform vec2 hizSize; // full-res size of Hi-Z texture (mip 0)

// Get cell index for a position at a given mip level
ivec2 hizGetCell(vec2 pos, int level) {
    vec2 cellCount = vec2(textureSize(hizBuffer, level));
    return ivec2(floor(pos * cellCount));
}

// Get minimum depth of a cell at a given mip level
float hizGetCellMinZ(ivec2 cell, int level) {
    vec2 cellCount = vec2(textureSize(hizBuffer, level));
    vec2 uv = (vec2(cell) + 0.5) / cellCount;
    return textureLod(hizBuffer, uv, float(level)).r;
}

// Intersect ray with cell boundary - returns parametric t along ray
float hizIntersectCellBoundary(vec2 o, vec2 d, ivec2 cell, int level, vec2 crossStep) {
    vec2 cellCount = vec2(textureSize(hizBuffer, level));
    vec2 boundary = (vec2(cell) + crossStep) / cellCount;
    vec2 delta = (boundary - o) / d;
    // Avoid negative or zero t from numerical issues
    delta = mix(delta, vec2(1e10), lessThanEqual(delta, vec2(0.0)));
    return min(delta.x, delta.y);
}

vec4 raytraceHiZ(vec3 fragpos, vec3 rvector, float roughness, float distanceFromCamera) {
    vec4 color = vec4(0.0);

    // Project start and compute ray in texture space (XY = [0,1] UV, Z = depth [0,1])
    vec3 startTS = nvec3(projectionMatrix * nvec4(fragpos)) * 0.5 + 0.5;

    // Compute max trace distance in view space, project endpoint
    vec3 endView = fragpos + normalize(rvector) * min(distanceFromCamera * 2.0, 80.0);
    vec4 endClip = projectionMatrix * nvec4(endView);
    // Early out: if endpoint is behind camera (W < 0), projection inverts XY - skip Hi-Z
    if (endClip.w < 0.0) return color;
    vec3 endTS = (endClip.xyz / endClip.w) * 0.5 + 0.5;

    // Ray parameterization: o + d*t, where t in [0,1]
    vec3 o = startTS;
    vec3 d = endTS - startTS;

    // Early out if ray has zero length in screen space
    if (length(d.xy) < 1e-6) return color;

    // Cross step direction (which cell boundary to cross based on ray direction)
    vec2 crossStep = vec2(d.x >= 0.0 ? 1.0 : 0.0, d.y >= 0.0 ? 1.0 : 0.0);
    vec2 crossOffset = (vec2(d.x >= 0.0 ? 1.0 : -1.0, d.y >= 0.0 ? 1.0 : -1.0)) / hizSize / 64.0;

    // Start at level 2 for efficient initial traversal
    int startLevel = 2;
    int stopLevel = 0;
    int maxLevel = hizMipLevels - 1;

    // Push ray to next cell boundary to avoid self-intersection
    float t = hizIntersectCellBoundary(o.xy, d.xy, hizGetCell(o.xy, startLevel), startLevel, crossStep);
    t = clamp(t + 1e-5, 0.0, 1.0);
    vec3 ray = o + d * t;

    int level = startLevel;
    bool hit = false;
    vec3 hitPos = vec3(0.0);
    float hitConfidence = 0.0;

    float thicknessBase = mix(0.02, 0.08, roughness);
    float thicknessDistance = distanceFromCamera * mix(0.0012, 0.0022, roughness);
    float maxThickness = thicknessBase + thicknessDistance;

    bool isBackward = d.z < 0.0;
    float rayDirSign = isBackward ? -1.0 : 1.0;
    float maxZ = isBackward ? 0.0 : 1.0;

    for (int i = 0; i < 128; ++i) {
        // Exit conditions
        if (ray.x < 0.0 || ray.x > 1.0 || ray.y < 0.0 || ray.y > 1.0) break;
        if (ray.z * rayDirSign > maxZ * rayDirSign) break;

        ivec2 cellIdx = hizGetCell(ray.xy, level);
        float cellMinZ = hizGetCellMinZ(cellIdx, level);

        // Forward ray: check if ray is below the cell's minimum depth
        if (!isBackward) {
            if (cellMinZ < ray.z) {
                // Ray is inside/below the cell volume - go to finer level
                level--;
                if (level < stopLevel) {
                    // At finest level: check thickness for valid hit
                    float thickness = ray.z - cellMinZ;
                    if (thickness < maxThickness) {
                        hit = true;
                        hitPos = ray;
                        hitConfidence = 1.0 - clamp(thickness / maxThickness, 0.0, 1.0);
                    }
                    break;
                }
            } else {
                // Ray is above the cell - try to advance to depth plane
                // Guard against near-horizontal rays (d.z ~ 0)
                if (abs(d.z) < 1e-7) {
                    // Can't advance in Z - cross cell boundary instead
                    float tBoundary = hizIntersectCellBoundary(o.xy, d.xy, cellIdx, level, crossStep);
                    tBoundary = clamp(tBoundary, 0.0, 1.0);
                    ray = o + d * tBoundary;
                    ray.xy += crossOffset;
                    level = min(level + 1, maxLevel);
                } else {
                    float tDepth = (cellMinZ - o.z) / d.z;
                    tDepth = clamp(tDepth, 0.0, 1.0);
                    vec3 tmpRay = o + d * tDepth;
                    ivec2 newCell = hizGetCell(tmpRay.xy, level);

                    if (any(notEqual(newCell, cellIdx))) {
                        // Crossed cell boundary - move to next cell, go coarser
                        float tBoundary = hizIntersectCellBoundary(o.xy, d.xy, cellIdx, level, crossStep);
                        tBoundary = clamp(tBoundary, 0.0, 1.0);
                        ray = o + d * tBoundary;
                        ray.xy += crossOffset;
                        level = min(level + 1, maxLevel);
                    } else {
                        // Stayed in same cell - accept the depth-plane intersection, go finer
                        ray = tmpRay;
                        level--;
                        if (level < stopLevel) {
                            float thickness = ray.z - cellMinZ;
                            if (thickness < maxThickness) {
                                hit = true;
                                hitPos = ray;
                                hitConfidence = 1.0 - clamp(thickness / maxThickness, 0.0, 1.0);
                            }
                            break;
                        }
                    }
                }
            }
        } else {
            // Backward ray: simpler logic
            if (cellMinZ > ray.z) {
                // Cell is above ray - cross to next cell
                float tBoundary = hizIntersectCellBoundary(o.xy, d.xy, cellIdx, level, crossStep);
                tBoundary = clamp(tBoundary, 0.0, 1.0);
                ray = o + d * tBoundary;
                ray.xy += crossOffset;
                level = min(level + 1, maxLevel);
            } else {
                // Ray inside cell - go finer
                level--;
                if (level < stopLevel) {
                    float thickness = abs(cellMinZ - ray.z);
                    if (thickness < maxThickness) {
                        hit = true;
                        hitPos = ray;
                        hitConfidence = 1.0 - clamp(thickness / maxThickness, 0.0, 1.0);
                    }
                    break;
                }
            }
        }
    }

    if (hit) {
        color = pow(texture(primaryScene, hitPos.xy), vec4(VSMOD_SSR_REFLECTION_DIMMING));
        color.a = clamp((1.0 - pow(cdist(hitPos.xy), 20.0)) * mix(0.65, 1.0, hitConfidence), 0.0, 1.0);
    }

    return color;
}
#endif

vec4 raytrace(vec3 fragpos, vec3 rvector, float roughness, float distanceFromCamera) {
    vec4 color = vec4(0.0);
    vec3 start = fragpos;
    rvector *= 1.2;
    fragpos += rvector;
    vec3 tvector = rvector;
    int sr = 0;

    bool hit = false;
    vec3 hitPos = vec3(0.0);
    float hitConfidence = 0.0;
    float thicknessBase = mix(0.02, 0.08, roughness);
    float thicknessDistance = distanceFromCamera * mix(0.0012, 0.0022, roughness);
    float thickness = thicknessBase + thicknessDistance;

    for (int i = 0; i < 25; ++i) {
        vec3 pos = nvec3(projectionMatrix * nvec4(fragpos)) * 0.5 + 0.5;
        if (pos.x < 0.0 || pos.x > 1.0 || pos.y < 0.0 || pos.y > 1.0 || pos.z < 0.0 || pos.z > 1.0) break;
        vec3 fragpos0 = vec3(pos.st, texture(gDepth, pos.st).r);
        fragpos0 = nvec3(invProjectionMatrix * nvec4(fragpos0 * 2.0 - 1.0));
        float err = distance(fragpos, fragpos0);
        bool isFurther = fragpos0.z < start.z;
        float adaptiveThickness = max(thickness, pow(length(rvector), 1.175) * mix(0.8, 1.3, roughness));
        if (err < adaptiveThickness && isFurther) {
            hit = true;
            hitPos = pos;
            hitConfidence = 1.0 - clamp(err / max(adaptiveThickness, 1e-4), 0.0, 1.0);
            sr++;

            if (sr >= maxf){
                break;
            }

            tvector -= rvector;
            rvector *= ref;
        }
        rvector *= inc;
        tvector += rvector;
        fragpos = start + tvector;
    }

    if (hit) {
        color = pow(texture(primaryScene, hitPos.st), vec4(VSMOD_SSR_REFLECTION_DIMMING));
        color.a = clamp((1.0 - pow(cdist(hitPos.st), 20.0)) * mix(0.65, 1.0, hitConfidence), 0.0, 1.0);
    }

    return color;
}

void main(void) {
    vec4 positionFrom = texture(gPosition, texcoord);
    vec4 normalSampleFull = texture(gNormal, texcoord);
    vec3 normalSample = normalSampleFull.xyz;
    if (vsmodNormalPacked8 > 0) {
        normalSample = normalize(normalSample * 2.0 - 1.0);
    }

    // Early out if no valid geometry data (prevents garbage on uninitialized pixels)
    // Use > 0.999 instead of >= 1.0 to handle float precision, matching the < 1.0 check below
    if (length(positionFrom.xyz) < 0.001 && positionFrom.w > 0.999) {
        outColor = vec4(0.0);
        return;
    }

    vec3 unitPositionFrom = normalize(positionFrom.xyz);
    vec3 normal = normalize(normalSample);
    vec3 pivot = normalize(reflect(unitPositionFrom, normal));

    outColor = vec4(0.0);

    if (positionFrom.w < 1.0) {
        vec4 tintSample = texture(gTint, texcoord);
        vec3 tint = tintSample.rgb;
        float roughness = clamp(tintSample.a, 0.0, 1.0);
        float smoothness = max(0.45, 1.0 - roughness);
        float waterMask = 1.0 - step(0.5, normalSampleFull.w);
        float distanceFromCamera = length(positionFrom.xyz);
        float distanceFade = smoothstep(30.0, 120.0, distanceFromCamera);

        vec3 positionFromUV = nvec3(projectionMatrix * positionFrom) * 0.5 + 0.5;
        vec3 positionFromDepth = vec3(positionFromUV.xy, texture(gDepth, positionFromUV.xy).r);
        positionFromDepth = nvec3(invProjectionMatrix * nvec4(positionFromDepth * 2.0 - 1.0));

        float occlusionDepthDelta = positionFromDepth.z - positionFrom.z;
        float occlusionFade = smoothstep(0.01, 0.08, occlusionDepthDelta);

        #if VSMOD_HAS_COMPUTE
        vec4 reflection = raytraceHiZ(positionFrom.xyz, pivot, roughness, distanceFromCamera);
        #else
        vec4 reflection = raytrace(positionFrom.xyz, pivot, roughness, distanceFromCamera);
        #endif
        reflection.a *= (1.0 - occlusionFade);
        vec4 skyColor = vec4(0.0);
        vec4 outGlow = vec4(0.0);

        vec4 worldNormal = invModelViewMatrix * vec4(normal, 0.0);
        float upness = clamp(dot(worldNormal.xyz, vec3(0.0, 1.0, 0.0)), 0.0, 1.0);
        pivot = (invModelViewMatrix * vec4(pivot, 0.0)).xyz;
        getSkyColorAt(pivot, sunPosition, 0.0, clamp(dayLight, 0.0, 1.0), horizonFog, skyColor, outGlow);
        vec4 skyNoise = NoiseFromPixelPosition(ivec2(gl_FragCoord.xy), ditherSeed, horizontalResolution);
        skyColor.rgb = max(vec3(0.0), skyColor.rgb - skyNoise.rgb);
        skyColor.rgb = pow(skyColor.rgb, vec3(VSMOD_SSR_REFLECTION_DIMMING));
        reflection.rgb = mix(reflection.rgb, skyColor.rgb, VSMOD_SSR_SKY_MIXIN * upness);
        reflection.rgb = mix(skyColor.rgb * upness, reflection.rgb, reflection.a);
        float missMask = 1.0 - step(0.001, reflection.a);
        float edgeMiss = smoothstep(0.72, 1.0, cdist(positionFromUV.xy));
        float roughFallback = smoothstep(0.45, 0.85, roughness);
        float fallbackWeight = clamp(missMask + edgeMiss * 0.35 + roughFallback * 0.25, 0.0, 1.0);
        vec3 envFallback = mix(skyColor.rgb, skyColor.rgb * tint, 0.12 + roughness * 0.2);
        reflection.rgb = mix(reflection.rgb, envFallback, fallbackWeight);
        reflection.a = max(reflection.a, fallbackWeight * mix(0.18, 0.45, roughness));

        // For rougher water, lean a bit on sky/fog but keep reflections dominant.
        reflection.rgb = mix(reflection.rgb, skyColor.rgb, roughness * 0.18);
        // Stronger floor on reflection visibility so SSR stays visible.
        reflection.a *= mix(0.85, 1.0, smoothness);
        float reflectionDistanceScale = mix(1.0, 0.9, distanceFade);
        reflection.rgb *= reflectionDistanceScale;
        reflection.a *= reflectionDistanceScale;

        float cosTheta = clamp(dot(normal, -unitPositionFrom), 0.0, 1.0);
        const float waterIor = 1.333;
        float r0 = pow((waterIor - 1.0) / (waterIor + 1.0), 2.0);
        float fresnel = r0 + (1.0 - r0) * pow(1.0 - cosTheta, 5.0);
        float transmission = clamp(1.0 - fresnel, 0.0, 1.0);

        outColor = reflection;
        outColor.a = 1.0;

        float tintInfluence = mix(VSMOD_SSR_TINT_INFLUENCE, clamp(VSMOD_SSR_TINT_INFLUENCE * 0.35, 0.08, 0.22), waterMask);
        tintInfluence = mix(tintInfluence, tintInfluence * (0.55 + 0.45 * transmission), waterMask);
        float tintDistanceBoost = mix(1.0, 1.2, distanceFade);
        outColor.rgb *= pow(tint, vec3(tintInfluence * tintDistanceBoost));
        outColor.rgb *= mix(1.0, 1.15, waterMask * fresnel);

        vec4 positionFromWorldSpace = invModelViewMatrix * vec4(positionFrom.xyz, 1.0);
        
        // Specular sun highlight on water (view-space calculation)
        vec3 viewDir = normalize(positionFrom.xyz);
        vec3 sunReflect = reflect(sunPosition, normal);
        float spec = pow(max(0.0, dot(-viewDir, sunReflect)), 48.0);
        float sunUp = clamp(sunPosition.y * 5.0, 0.0, 1.0);
        float clearSky = 1.0 - clamp(horizonFog * 1.5, 0.0, 1.0); // fade in overcast/rain
        float specDistanceScale = mix(1.0, 0.5, distanceFade);
        outColor.rgb += vec3(1.0, 0.95, 0.8) * spec * VSMOD_SSR_SPECULAR * 3.0 * dayLight * sunUp * clearSky * specDistanceScale;
        
        float fogLevel = getFogLevelDeferred(length(positionFrom), fogMinIn, fogDensityIn, positionFromWorldSpace.y);
        outColor = applyFog(outColor, fogLevel);

        float waterAlphaScale = mix(1.0, 0.95, waterMask);
        float sceneDepth = linearDepth(texture(gDepth, texcoord).r);
        float surfaceDepth = -positionFrom.z;
        float shoreDepthDelta = max(0.0, sceneDepth - surfaceDepth);
        float shoreFoamMask = 1.0 - smoothstep(0.1, 1.2, shoreDepthDelta);
        float foamPreserve = mix(1.0, mix(0.4, 1.0, 1.0 - shoreFoamMask), waterMask);
        float reflectMask = 1.0 - positionFrom.w;
        reflectMask = mix(reflectMask, clamp(reflectMask * 1.25 + 0.05, 0.0, 1.0), waterMask);
        outColor.a *= reflectMask * fresnel * mix(0.85, 1.0, smoothness) * waterAlphaScale * foamPreserve;
        float reflectionBoost = clamp(1.0 + smoothness * 0.75, 1.0, 2.2);
        outColor.a = min(1.0, outColor.a * reflectionBoost);
        
        float reflectionBrightness = dot(outColor.rgb, vec3(0.299, 0.587, 0.114));
        if (reflectionBrightness > 0.85) {
            outColor.rgb *= 0.85 / reflectionBrightness;
        }

        // No screen-space foam overlay; foam handled in water shading.

        if (hasHistory > 0)
        {
            vec4 prevClip = prevViewProj * vec4(positionFromWorldSpace.xyz, 1.0);
            if (abs(prevClip.w) > 1e-5)
            {
                vec3 prevNdc = prevClip.xyz / prevClip.w;
                vec2 prevUv = prevNdc.xy * 0.5 + 0.5;
                if (prevUv.x >= 0.0 && prevUv.x <= 1.0 && prevUv.y >= 0.0 && prevUv.y <= 1.0)
                {
                    vec3 history = texture(ssrHistory, prevUv).rgb;
                    vec3 prevPos = texture(gPosition, prevUv).xyz;
                    vec3 prevNormal = decodeGNormal(texture(gNormal, prevUv).xyz);
                    float prevDistance = length(prevPos);
                    float positionMismatch = abs(prevDistance - distanceFromCamera);
                    float normalMismatch = 1.0 - clamp(dot(prevNormal, normal), 0.0, 1.0);
                    float disocclusionReject = smoothstep(0.35, 2.4, positionMismatch) + smoothstep(0.12, 0.42, normalMismatch);
                    float historyValidity = 1.0 - clamp(disocclusionReject, 0.0, 1.0);

                    float historyStrength = mix(historyBlend * 0.58, historyBlend * 0.92, smoothness);
                    historyStrength = min(1.0, historyStrength * mix(0.85, 1.3, distanceFade)) * historyValidity;

                    vec3 clampRange = vec3(mix(0.05, 0.18, smoothness));
                    vec3 historyClamped = clamp(history, outColor.rgb - clampRange, outColor.rgb + clampRange);
                    outColor.rgb = mix(outColor.rgb, historyClamped, historyStrength);
                }
            }
        }
    }

    //outColor.rgb = normal;
    //outColor.a = 1;
}
