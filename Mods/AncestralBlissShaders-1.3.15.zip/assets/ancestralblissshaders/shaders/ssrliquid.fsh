#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

uniform sampler2D terrainTex;
uniform vec3 playerpos;
uniform mat4 modelViewMatrix;
uniform float dropletIntensity = 0;
uniform float playerUnderwater;
uniform vec4 cameraWorldPosition;
uniform vec4 waterMurkColor;
uniform sampler2D sceneDepth;
uniform mat4 invProjectionMatrix;
uniform vec2 frameSize;
uniform int vsmodMrtMode;
#define VSMOD_NORMAL_PACK_8BIT (VSMOD_HAS_SHADER_BIT_ENCODING == 0)
const vec4 rgbaFog = vec4(0.0);

in vec4 worldPos;
in vec4 fragPosition;
in vec3 fragWorldPos;
in vec4 gnormal;
in vec3 worldNormal;
in vec2 flowVectorf;
in vec2 uv;
flat in int waterFlags;
in float alpha;
flat in int skyExposed;

layout(location = 0) out vec4 outGPosition;
layout(location = 1) out vec4 outGNormal;
layout(location = 2) out vec4 outTint;
#if VSMOD_REFRACT > 0
layout(location = 3) out vec4 outRefraction;
#endif

#if VSMOD_REFRACT > 0
void writeGBuffer(vec4 position, vec4 normal, vec4 tint, vec4 refraction) {
    if (vsmodMrtMode == 2) {
        outGPosition = tint;
        outGNormal = refraction;
        outTint = vec4(0.0);
        outRefraction = vec4(0.0);
    } else if (vsmodMrtMode == 1) {
        outGPosition = position;
        outGNormal = normal;
        outTint = vec4(0.0);
        outRefraction = vec4(0.0);
    } else {
        outGPosition = position;
        outGNormal = normal;
        outTint = tint;
        outRefraction = refraction;
    }
}
#else
void writeGBuffer(vec4 position, vec4 normal, vec4 tint, vec4 refraction) {
    if (vsmodMrtMode == 2) {
        outGPosition = tint;
        outGNormal = refraction;
        outTint = vec4(0.0);
    } else if (vsmodMrtMode == 1) {
        outGPosition = position;
        outGNormal = normal;
        outTint = vec4(0.0);
    } else {
        outGPosition = position;
        outGNormal = normal;
        outTint = tint;
    }
}
#endif

#include vertexflagbits.ash
#include colormap.fsh
#include fogandlight.fsh
#include noise3d.ash
#include wavenoise.ash

// Gentle shoreline foam aligned with vanilla styling
#if VSMOD_SHORELINEFOAM > 0
vec3 vsmod_applyShorelineFoam(vec3 baseColor, float depth, vec3 worldPos) {
    float foamNoise = fract(sin(dot(worldPos.xz * 2.0, vec2(12.9898, 78.233))) * 43758.5453);
    float edgeFactor = smoothstep(0.0, 0.3, depth) * smoothstep(1.2, 0.5, depth);
    float timeOffset = sin(waterWaveCounter * 1.2 + worldPos.x * 0.15 + worldPos.z * 0.15) * 0.25;
    float foamMask = smoothstep(0.65, 0.95, foamNoise + timeOffset) * edgeFactor;

    vec3 foamColor = mix(baseColor, vec3(0.92, 0.97, 1.0), 0.7);
    return mix(baseColor, foamColor, clamp(foamMask * 0.45, 0.0, 0.45));
}
#endif

// Kept inline so the first vanilla shader load (before Harmony injection) remains valid.
vec2 droplethash3(vec2 p)
{
    vec2 q = vec2(dot(p, vec2(12.71, 31.17)), dot(p, vec2(26.95, 18.33)));
    return fract(sin(q) * 43758.5453);
}

float dropletnoise(in vec2 x, in float waveCounter)
{
    if (dropletIntensity < 0.001) return 0.0;

    x *= dropletIntensity;
    vec2 p = floor(x);
    vec2 f = fract(x);

    float va = 0.0;
    for (int j = -1; j <= 1; j++)
    for (int i = -1; i <= 1; i++)
    {
        vec2 g = vec2(float(i), float(j));
        vec2 o = droplethash3(p + g);
        vec2 r = g - f + o;
        float d = length(r) / dropletIntensity;

        float a = max(cos(d - waveCounter * 2.7 + (o.x + o.y) * 5.0), 0.0);
        a = smoothstep(0.97, 0.999, a);

        float ripple = mix(a, 0.0, d);
        va += max(ripple, 0.0);
    }

    return va;
}

#ifndef VSMOD_SSR_WAVE_SIZE
#define VSMOD_SSR_WAVE_SIZE 70.0
#endif

#ifndef VSMOD_SSR_SPECULAR
#define VSMOD_SSR_SPECULAR 1.0
#endif

void generateNoiseBump(inout vec3 normalMap, vec3 position, float div) {
    const vec3 offset = vec3(0.05, 0.0, 0.0);
    vec3 posCenter = position.xyz;
    vec3 posNorth = posCenter - offset.zyx;
    vec3 posEast = posCenter + offset.xzy;

    float sizeScale = max(0.35, VSMOD_SSR_WAVE_SIZE / 0.7);
    float val0 = generateWaveNoise(posCenter, div, sizeScale);
    float val1 = generateWaveNoise(posNorth, div, sizeScale);
    float val2 = generateWaveNoise(posEast, div, sizeScale);

    float zDelta = (val0 - val1);
    float xDelta = (val2 - val0);

    normalMap += vec3(xDelta * 0.5, zDelta * 0.5, 0.0);
}

void generateNoiseParallax(inout vec3 normalMap, vec3 viewVector, float div, out vec3 parallaxPos) {
    vec3 targetPos = fragWorldPos.xyz;

    float sizeScale = max(0.35, VSMOD_SSR_WAVE_SIZE / 0.7);
    float currentNoise = generateWaveNoise(fragWorldPos.xyz, div, sizeScale);
    targetPos.xz += (currentNoise * viewVector.xy) * 0.4;

    generateNoiseBump(normalMap, targetPos, div);
    parallaxPos = targetPos;
}

float generateSplash(vec3 pos)
{
    vec3 localPos = fract(pos.xyz / 512.0) * 512.0;
    vec2 uv = 5.0 * pos.xz;

    return dropletnoise(uv, waterWaveCounter);
}

void generateSplashBump(inout vec3 normalMap, vec3 pos)
{
    const vec3 deltaPos = vec3(0.01, 0.0, 0.0);
    vec3 startPos = pos - deltaPos.xyx * 0.5;

    float val0 = generateSplash(startPos);
    float val1 = generateSplash(startPos + deltaPos.xyz);
    //float val2 = generateSplash(pos - deltaPos.xyz);
    float val2 = generateSplash(startPos + deltaPos.zyx);
    //float val4 = generateSplash(pos - deltaPos.zyx);

    float xDelta = (val1 - val0);
    float zDelta = (val2 - val0);

    normalMap += vec3(xDelta, zDelta, 0) * 0.75;
}

// https://gamedev.stackexchange.com/questions/86530/is-it-possible-to-calculate-the-tbn-matrix-in-the-fragment-shader
#if VSMOD_HAS_DF_DX_DY
mat3 cotangentFrame(vec3 N, vec3 p, vec2 uv) {
    vec3 dp1 = dFdx(p);
    vec3 dp2 = dFdy(p);
    vec2 duv1 = dFdx(uv);
    vec2 duv2 = dFdy(uv);

    vec3 dp2perp = cross(dp2, N);
    vec3 dp1perp = cross(N, dp1);
    vec3 T = dp2perp * duv1.x + dp1perp * duv2.x;
    vec3 B = dp2perp * duv1.y + dp1perp * duv2.y;

    float invmax = inversesqrt(max(dot(T, T), dot(B, B)));
    return mat3(T * invmax, B * invmax, N);
}
#else
mat3 cotangentFrame(vec3 N, vec3 p, vec2 uv) {
    vec3 T = normalize(cross(N, vec3(0.0, 1.0, 0.0)));
    if (length(T) < 0.001) T = normalize(cross(N, vec3(1.0, 0.0, 0.0)));
    vec3 B = cross(N, T);
    return mat3(T, B, N);
}
#endif

float vsmod_luma(vec3 color) {
    return dot(color, vec3(0.299, 0.587, 0.114));
}

void main()
{
    float isWater = ((waterFlags & LiquidWeakWaveBitMask) > 0) ? 0.0 : 1.0;
    float myAlpha = alpha * isWater;
    if (myAlpha < 0.005) discard;

    vec4 texColor = texture(terrainTex, uv);
    
    // Non-water liquids (barrels, etc.) - use vanilla-like rendering
    if (isWater < 0.5) {
        vec3 normal = normalize(gnormal.xyz);
        #if VSMOD_NORMAL_PACK_8BIT
            normal = normal * 0.5 + 0.5;
        #endif
        writeGBuffer(vec4(fragPosition.xyz, 0.0), vec4(normal, playerUnderwater),
            vec4(texColor.rgb, 0.0), vec4(0.0));
        return;
    }

    // apply waves
    // apply waves
    float baseCaustics = length(flowVectorf) > 0.001 ? 0 : 1;
    
    // Calculate water depth once for all effects
    float waterDepth = length(worldPos.xyz - cameraWorldPosition.xyz);
    
    // Caustics intensity variation - depth and angle dependent (smoothed)
    float causticsDepthFactor = smoothstep(0.5, 15.0, waterDepth);
    float causticsAngleFactor = clamp(abs(dot(normalize(cameraWorldPosition.xyz - worldPos.xyz), worldNormal)), 0.7, 1.0); 
    float caustics = baseCaustics * mix(0.8, 1.0, causticsDepthFactor) * causticsAngleFactor;
    float div = ((waterFlags & LiquidWeakWaveBitMask) > 0) ? 90 : 10; //Half triangle bug occurred due to not using latest water bitmaps
    //float noise = generateNoise(worldPos.xyz + playerpos.xyz, div, wind);

    mat3 tbn = cotangentFrame(worldNormal, worldPos.xyz, uv);
    mat3 invTbn = transpose(tbn);

    //vec3 normalMap = vec3(noise, noise, 0.0);
    vec3 normalMap = vec3(0.0);
    vec3 parallaxPos = fragWorldPos.xyz;
    vec3 viewTangent = normalize(invTbn * (worldPos.xyz - cameraWorldPosition.xyz));
    generateNoiseParallax(normalMap, viewTangent, div, parallaxPos);

    if (dropletIntensity > 0.001) {
        generateSplashBump(normalMap, parallaxPos);
    }

    vec3 worldNormalMap = tbn * normalMap;
    vec3 camNormalMap = (modelViewMatrix * vec4(worldNormalMap, 0.0)).xyz;
    vec3 myGNormal = gnormal.xyz;

    if (dot(gnormal.xyz, fragPosition.xyz) > 0) {
        // flip the normal if viewed from behind
        myGNormal = -gnormal.xyz;
    }

    // Derive a water roughness signal from wave normal intensity and splashes; store in tint alpha.
    // Keep roughness bounded so reflections never vanish completely.
    float waveRough = clamp(length(normalMap.xy) * 1.6, 0.0, 0.22);
    float splashRough = dropletIntensity > 0.001 ? clamp(length(normalMap.xy) * 0.5, 0.0, 0.15) : 0.0;
    float roughness = clamp(0.05 + waveRough + splashRough, 0.05, 0.30);

    vec4 refraction = vec4(0.0);
    #if VSMOD_REFRACT > 0
    // Refraction distortion intensity scaling - depth-based refraction strength
    float refractionDepth = clamp(waterDepth / 10.0, 0.15, 1.0);
    vec2 baseRefraction = (-camNormalMap.xy * 1.6) / fragPosition.z;
    
    // Chromatic aberration refraction - RGB channel separation
    vec2 refractionR = baseRefraction * refractionDepth * 1.02;
    vec2 refractionG = baseRefraction * refractionDepth * 1.00;
    vec2 refractionB = baseRefraction * refractionDepth * 0.98;
    
    refraction = vec4(refractionG, refractionR.x - refractionG.x, refractionB.y - refractionG.y);
    refraction.w = roughness;
    #endif
    vec3 packedNormal = normalize(camNormalMap*2.0 + myGNormal);
    #if VSMOD_NORMAL_PACK_8BIT
        packedNormal = packedNormal * 0.5 + 0.5;
    #endif
    float foamMaskOut = 0.0;
    float foamIntensity = 0.0;

    // Fresnel reflections - angle-dependent reflection strength
    vec3 viewDir = normalize(cameraWorldPosition.xyz - worldPos.xyz);
    vec3 surfaceNormal = normalize(worldNormalMap + worldNormal);
    float cosTheta = clamp(dot(viewDir, surfaceNormal), 0.0, 1.0);
    const float waterIor = 1.333;
    float r0 = pow((waterIor - 1.0) / (waterIor + 1.0), 2.0);
    float fresnel = r0 + (1.0 - r0) * pow(1.0 - cosTheta, 5.0);
    
    // Reflection masking by angle - favor grazing reflections to avoid oily look.
    float angleMask = smoothstep(0.05, 0.95, 1.0 - cosTheta);
    fresnel = mix(fresnel, fresnel * angleMask, 0.35);
    float transmission = clamp(1.0 - fresnel, 0.0, 1.0);
    
    // Anisotropic wave reflections disabled with waves removed.
    float anisotropicReflection = 1.0;

    // Water color - darker, muddier tint with depth-to-bottom ramp (10 blocks -> fully muddy)
    vec2 depthUv = gl_FragCoord.xy / frameSize;
    float sceneDepth = texture(sceneDepth, depthUv).r;
    vec4 depthNdc = vec4(depthUv * 2.0 - 1.0, sceneDepth * 2.0 - 1.0, 1.0);
    vec4 depthView = invProjectionMatrix * depthNdc;
    depthView /= max(depthView.w, 0.0001);
    float surfaceDepth = -fragPosition.z;
    float bottomDepth = -depthView.z;
    float columnDepth = max(0.0, bottomDepth - surfaceDepth);
    float depthMurk = clamp(columnDepth / 10.0, 0.0, 1.0);

    vec3 waterColorTint = vec3(1.0);
    float murkStrength = 0.0;
    if (isWater > 0.5) {
        float murkLuma = vsmod_luma(waterMurkColor.rgb);
        float murkSat = length(waterMurkColor.rgb - vec3(murkLuma));
        float turbidity = clamp(depthMurk * 0.55 + murkSat * 1.35 + (1.0 - murkLuma) * 0.35, 0.0, 1.0);
        float clearWeight = 1.0 - smoothstep(0.25, 0.55, turbidity);
        float turbidWeight = smoothstep(0.45, 0.85, turbidity);
        float riverWeight = max(0.0, 1.0 - clearWeight - turbidWeight);

        // Freshwater profile blend: clear lake, river, turbid.
        vec3 absorption = clearWeight * vec3(0.10, 0.035, 0.012) +
                          riverWeight * vec3(0.16, 0.055, 0.018) +
                          turbidWeight * vec3(0.26, 0.095, 0.038);
        vec3 waterTransmission = exp(-absorption * columnDepth);
        vec3 deepWater = clearWeight * vec3(0.08, 0.20, 0.26) +
                         riverWeight * vec3(0.06, 0.12, 0.16) +
                         turbidWeight * vec3(0.11, 0.16, 0.15);
        // Shallow = clearer, deep = scatter color dominates
        waterColorTint = mix(deepWater, vec3(0.22, 0.24, 0.26), waterTransmission.r);

        // Climate-based murk tint (reduced desaturation to preserve biome color)
        vec3 murkTint = mix(vec3(murkLuma), waterMurkColor.rgb, 0.6);
        float murkStrengthBase = mix(0.25, 0.6, depthMurk);
        murkStrength = mix(murkStrengthBase, max(murkStrengthBase, 0.75), turbidWeight * 0.6);
        waterColorTint = mix(waterColorTint, murkTint * 0.3, murkStrength);
    } else {
        waterColorTint = texColor.rgb;
    }
    
    // Underwater ambient shift tuned for softer freshwater attenuation
    if (playerUnderwater > 0.5) {
        float underwaterDepth = clamp(waterDepth * 0.05, 0.0, 1.0);
        float underwaterDarken = mix(1.0, 0.84, underwaterDepth * 0.6);
        waterColorTint *= underwaterDarken;
    }

    vec3 finalWaterColor = waterColorTint;
    float shoreReflectionMask = 1.0;
#if VSMOD_SHORELINEFOAM > 0
    float shoreDepth = clamp(columnDepth, 0.0, 2.0);
    finalWaterColor = vsmod_applyShorelineFoam(finalWaterColor, shoreDepth, worldPos.xyz);
    float shoreFoam = 1.0 - smoothstep(0.05, 0.65, columnDepth);
    shoreReflectionMask = mix(1.0, 0.78, shoreFoam);
#endif

    // Reflection color temperature - sky cool, sun warm (subtle)
    float sunUp = clamp(lightPosition.y * 2.0, 0.0, 1.0); // fade out at night
    float sunAlignment = max(0.0, dot(viewDir, normalize(lightPosition)));
    vec3 reflectionTint = mix(vec3(0.95, 0.98, 1.05), vec3(1.05, 1.02, 0.95), sunAlignment);
    
    // Specular highlight - intensity controlled by VSMOD_SSR_SPECULAR, fades at night
    float specularHighlight = pow(max(0.0, dot(reflect(-viewDir, surfaceNormal), normalize(lightPosition))), 32.0);
    vec3 specularColor = mix(vec3(0.9, 0.95, 1.0), vec3(1.0, 0.95, 0.8), sunAlignment) * specularHighlight * sunUp;
    
    finalWaterColor += specularColor * VSMOD_SSR_SPECULAR * mix(1.0, 0.75, murkStrength);
    finalWaterColor *= mix(0.9, 1.05, transmission);

    // Reflection intensity variation with anisotropic enhancement and cloud darkening
    float reflectionIntensity = mix(1.4, 0.95, roughness) * fresnel * anisotropicReflection;
    // Clouds should darken reflections (less sun alignment = more clouds = darker reflection)
    float cloudDarkening = mix(0.85, 1.0, sunAlignment);
    reflectionIntensity *= cloudDarkening * shoreReflectionMask * mix(1.0, 0.9, murkStrength); // Apply shore masking

    // Apply final water color with all enhancements
    vec3 baseWaterColor = finalWaterColor;

    writeGBuffer(vec4(fragPosition.xyz, reflectionIntensity), vec4(packedNormal, foamMaskOut),
        vec4(baseWaterColor, roughness), refraction);
}
