#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

uniform sampler2D terrainTex;
uniform sampler2D terrainTexLinear;
uniform float playerUnderwater;
uniform int vsmodMrtMode;
#define VSMOD_NORMAL_PACK_8BIT (VSMOD_HAS_SHADER_BIT_ENCODING == 0)

in vec4 fragPosition;
flat in int renderFlags;
in vec4 gnormal;
in vec2 uv;

layout(location = 0) out vec4 outGPosition;
layout(location = 1) out vec4 outGNormal;
layout(location = 2) out vec4 outTint;
#if VSMOD_REFRACT > 0
layout(location = 3) out vec4 outRefraction;
#endif

#if VSMOD_REFRACT > 0
void writeGBuffer(vec4 position, vec4 normal, vec4 tint, vec4 refraction) {
    if (vsmodMrtMode == 2) {
        outGPosition = tint;
        outGNormal = refraction;
        outTint = vec4(0.0);
        outRefraction = vec4(0.0);
    } else if (vsmodMrtMode == 1) {
        outGPosition = position;
        outGNormal = normal;
        outTint = vec4(0.0);
        outRefraction = vec4(0.0);
    } else {
        outGPosition = position;
        outGNormal = normal;
        outTint = tint;
        outRefraction = refraction;
    }
}
#else
void writeGBuffer(vec4 position, vec4 normal, vec4 tint, vec4 refraction) {
    if (vsmodMrtMode == 2) {
        outGPosition = tint;
        outGNormal = refraction;
        outTint = vec4(0.0);
    } else if (vsmodMrtMode == 1) {
        outGPosition = position;
        outGNormal = normal;
        outTint = vec4(0.0);
    } else {
        outGPosition = position;
        outGNormal = normal;
        outTint = tint;
    }
}
#endif

#include vertexflagbits.ash
#include colormap.fsh


void main()
{
    if ((renderFlags & ReflectiveBitMask) == 0) discard;
    vec4 color = texture(terrainTex, uv);
    if (color.a < 0.5) discard;

    vec4 refraction = vec4(0.0, 0.0, 0.0, 1.0);
    outGPosition = vec4(fragPosition.xyz, 0.0);
    vec3 packedNormal = normalize(gnormal.xyz);
    #if VSMOD_NORMAL_PACK_8BIT
        packedNormal = packedNormal * 0.5 + 0.5;
    #endif
    // Non-water reflective geometry: keep w=1 so SSR out pass does not treat it as water.
    outGNormal = vec4(packedNormal, 1.0);
    color = vec4(pow(color.rgb, vec3(2.2)), 1.0);
    outTint = vec4(getColorMapped(terrainTexLinear, color).rgb, 0.0);
    writeGBuffer(outGPosition, outGNormal, outTint, refraction);
}
