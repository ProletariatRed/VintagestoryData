
#version 330 core

uniform sampler2D gDepth;
uniform sampler2D gNormal;
uniform sampler2D gpositionScene;
uniform int vsmodNormalPacked8;

uniform mat4 invProjectionMatrix;
uniform mat4 invModelViewMatrix;

uniform float dayLight;
uniform vec3 sunPosition;
uniform vec3 playerPos;

in vec2 texcoord;
out float outStrength;

uniform float fogDensityIn;
uniform float fogMinIn;
uniform vec4 rgbaFog;

#include noise3d.ash
#include fogandlight.fsh
#include wavenoise.ash
#include deferredfogandlight.fsh

void main(void)
{
    float underwater = texture(gNormal, texcoord).w;
    if (underwater > 0.5) discard;

    vec3 surfaceNormal = texture(gNormal, texcoord).xyz;
    if (vsmodNormalPacked8 > 0) {
        surfaceNormal = surfaceNormal * 2.0 - 1.0;
    }
    surfaceNormal = normalize(surfaceNormal);
    float waveSlope = clamp(length(surfaceNormal.xz), 0.0, 1.0);

    float projectedZ = texture(gDepth, texcoord).r;
    vec4 screenPosition = vec4(vec3(texcoord, projectedZ) * 2.0 - 1.0, 1.0);
    screenPosition = invProjectionMatrix * screenPosition;
    screenPosition.xyz /= screenPosition.w;
    screenPosition.w = 1.0;
    vec4 worldPosition = invModelViewMatrix * screenPosition;
    vec4 cameraWorldPos = invModelViewMatrix * vec4(0.0, 0.0, 0.0, 1.0);

    vec3 absWorldPos = worldPosition.xyz + playerPos;

    float shadowBrightness = getPCFBrightnessAt(worldPosition);
    float shadowStrength = clamp(pow(shadowIntensity, 2.0), 0.2, 1.0);
    float waveNoise = generateCausticsNoise(absWorldPos + surfaceNormal * 0.4, sunPosition) * 3.2;

    // Depth attenuation: caustics fade from full at surface to 0 at 7 blocks deep
    vec4 waterView = texture(gpositionScene, texcoord);
    float hasWater = step(0.001, waterView.w);
    vec4 waterWorld = invModelViewMatrix * vec4(waterView.xyz, 1.0);
    vec3 absWaterPos = waterWorld.xyz + playerPos;
    float waterSurfaceY = mix(playerPos.y + 1.0, absWaterPos.y, hasWater);
    float depthBelowSurface = max(0.0, waterSurfaceY - absWorldPos.y);
    float depthFade = (1.0 - pow(clamp(depthBelowSurface / 14.0, 0.0, 1.0), 0.7)) * hasWater;
    float depthSoften = smoothstep(0.25, 1.25, depthBelowSurface);

    float surfaceWave = abs(generateWaveNoise(absWaterPos, 60.0, max(0.35, VSMOD_SSR_WAVE_SIZE / 0.7)));
    float roughnessBoost = mix(0.8, 1.35, clamp(surfaceWave * 2.5 + waveSlope * 0.9, 0.0, 1.0));

    // Sun angle attenuation: caustics fade at low sun angles (Fresnel reflection at surface)
    float sunAngleFade = clamp(sunPosition.y * 1.5, 0.0, 1.0);

    outStrength = waveNoise * roughnessBoost * shadowBrightness * shadowStrength * depthFade * depthSoften * sunAngleFade + 0.5;
}
