#version 330 core
#extension GL_ARB_explicit_attrib_location: enable

uniform sampler2D terrainTex;
uniform float playerUnderwater;
uniform int vsmodMrtMode;
#define VSMOD_NORMAL_PACK_8BIT (VSMOD_HAS_SHADER_BIT_ENCODING == 0)
in vec2 uv;

flat in int renderFlags;
in vec3 fragWorldPos;
in vec4 gnormal;
in vec4 gposition;


layout(location = 0) out vec4 outGPosition;
layout(location = 1) out vec4 outGNormal;
layout(location = 2) out vec4 outTint;
#if VSMOD_REFRACT > 0
layout(location = 3) out vec4 outRefraction;
#endif

#if VSMOD_REFRACT > 0
void writeGBuffer(vec4 position, vec4 normal, vec4 tint, vec4 refraction) {
    if (vsmodMrtMode == 2) {
        outGPosition = tint;
        outGNormal = refraction;
        outTint = vec4(0.0);
        outRefraction = vec4(0.0);
    } else if (vsmodMrtMode == 1) {
        outGPosition = position;
        outGNormal = normal;
        outTint = vec4(0.0);
        outRefraction = vec4(0.0);
    } else {
        outGPosition = position;
        outGNormal = normal;
        outTint = tint;
        outRefraction = refraction;
    }
}
#else
void writeGBuffer(vec4 position, vec4 normal, vec4 tint, vec4 refraction) {
    if (vsmodMrtMode == 2) {
        outGPosition = tint;
        outGNormal = refraction;
        outTint = vec4(0.0);
    } else if (vsmodMrtMode == 1) {
        outGPosition = position;
        outGNormal = normal;
        outTint = vec4(0.0);
    } else {
        outGPosition = position;
        outGNormal = normal;
        outTint = tint;
    }
}
#endif

#include vertexflagbits.ash
#include colormap.fsh
#include noise3d.ash

void main()
{
    if ((renderFlags & ReflectiveBitMask) == 0) discard;
    vec4 color = texture(terrainTex, uv);
    if (color.a < 0.02) discard;

    float refractionMultiplier = 10.0;
    float noise = cnoise(fragWorldPos) * 0.01;
    if ((renderFlags & 7) == 1) {
        // ice has z-offset 1, glass has 0 or 2
        noise += gnoise(fragWorldPos*10.0) * 0.02;
        refractionMultiplier = 5.0;
    }

    vec4 refraction = vec4(0.0);
    #if VSMOD_REFRACT > 0
    refraction = vec4(vec2(noise * refractionMultiplier / gposition.z), 0.0, 0.0);
    #endif
    vec3 packedNormal = normalize(gnormal.xyz + vec3(noise));
    #if VSMOD_NORMAL_PACK_8BIT
        packedNormal = packedNormal * 0.5 + 0.5;
    #endif
    // Non-water reflective geometry: keep w=1 so SSR out pass does not treat it as water.
    writeGBuffer(vec4(gposition.xyz, 0.0), vec4(packedNormal, 1.0),
        vec4(color.xyz, 0.0), refraction);
}
